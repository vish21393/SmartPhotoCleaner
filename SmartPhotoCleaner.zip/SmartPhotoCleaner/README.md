# Smart Photo Cleaner (Android Studio Project)

An on-device intelligent Android app (Kotlin + Jetpack Compose + Material 3) that scans your device gallery, detects visually similar/burst photos, identifies blurry or poorly exposed shots, and suggests safe deletions to free up storage.

## Key Features
- **Similar Photo Clustering (`PhotoAnalyzer.kt`)**: Computes a 64-bit Difference Hash (dHash) for each photo and groups visually similar shots by Hamming distance, automatically marking the highest-scoring photo as **Best** and pre-selecting duplicates.
- **Bad Photo Detection (`PhotoAnalyzer.kt`)**:
  - **Blur detection** via 3x3 Laplacian variance on grayscale thumbnails.
  - **Exposure analysis** for underexposed (too dark) and overexposed (blown-out) shots.
  - **Low-resolution check** for tiny or heavily downscaled images.
- **Safe System Deletion (`MediaStoreRepository.kt`)**: Uses `MediaStore.createDeleteRequest` on Android 11+ (API 30+) so deletions go through Android's native confirmation dialog.

## How to Build the APK in Android Studio
1. Unzip `SmartPhotoCleaner-AndroidProject.zip`.
2. Open **Android Studio** -> **File > Open...** -> select the `SmartPhotoCleaner` folder.
3. Let Gradle sync (it will download the Android Gradle Plugin and Jetpack Compose dependencies).
4. Connect an Android device (or start an Emulator) and click **Run** to install directly, **or** go to **Build > Build Bundle(s) / APK(s) > Build APK(s)** to generate `app/build/outputs/apk/debug/app-debug.apk`.
