# Smart Photo Cleaner v2.0

Resource-aware, incremental on-device photo intelligence app built for constrained (<1 GB free RAM) Android phones:
- Global SQLite `PhotoIndex` + 8-bucket `dHash` cross-page matching
- Incremental grouping with separate `anchor_photo_id` and `best_photo_id`
- Adaptive 1–2 worker throttling based on independent memory and thermal checks
- 3×3 regional blur detection, luminance histogram, flat-image guard, and SHA-256 exact-duplicate verification
- Persistent per-photo `KEEP` / `EXCLUDE` decisions and Android 14+ partial-access support
