# Smart Photo Cleaner (Android Studio Project)

An on-device intelligent Android app (Kotlin + Jetpack Compose + Material 3) that scans your device gallery, detects visually similar/burst photos, identifies blurry or poorly exposed shots, and suggests safe deletions to free up storage.
