package com.smartphotocleaner.app

import android.net.Uri
import com.smartphotocleaner.app.intelligence.ImageQualityEngine
import com.smartphotocleaner.app.model.BadPhotoReason
import com.smartphotocleaner.app.model.IndexedPhoto
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ImageQualityAndHashTest {

    @Test
    fun extractBucketsHandlesNegativeSignedLongCorrectly() {
        val hash = -1L // 0xFFFFFFFFFFFFFFFF
        val buckets = ImageQualityEngine.extractBuckets(hash)
        assertEquals(8, buckets.size)
        for (b in buckets) {
            assertEquals(255, b)
        }
    }

    @Test
    fun flatWhiteAndFlatBlackScreenshotsNeverMatch() {
        val white = IndexedPhoto(
            mediaId = 1L,
            uri = Uri.EMPTY,
            displayName = "white.png",
            volumeName = "external",
            dHash = 0L,
            colorSignature = IntArray(48) { 250 },
            width = 1080,
            height = 2400,
            brightness = 250.0,
            sharpness = 20.0,
            gradientEntropy = 1.0,
            fileSize = 100_000L,
            modifiedTime = 1000L,
            qualityScore = 70,
            reasons = emptyList(),
            scanVersion = 2
        )
        val black = white.copy(
            mediaId = 2L,
            displayName = "black.png",
            colorSignature = IntArray(48) { 5 },
            brightness = 5.0
        )
        assertFalse(ImageQualityEngine.areVisuallySimilar(white, black))
    }

    @Test
    fun portraitBokehWithSharpCenterIsNotMarkedBlurry() {
        val size = ImageQualityEngine.ANALYSIS_GRID
        val pixels = IntArray(size * size)
        val gray = DoubleArray(size * size)

        // Smooth background, sharp checkerboard in the center tile
        for (y in 0 until size) {
            for (x in 0 until size) {
                val inCenter = y in (size / 3)..(2 * size / 3) && x in (size / 3)..(2 * size / 3)
                val v = if (inCenter && ((x + y) % 2 == 0)) 220 else 60
                pixels[y * size + x] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
            }
        }

        val metrics = ImageQualityEngine.evaluateQualityFromGrid(pixels, gray, size)
        val reasons = ImageQualityEngine.classifyReasons(metrics, 3000, 4000)
        assertTrue(BadPhotoReason.BLURRY !in reasons)
    }
}
