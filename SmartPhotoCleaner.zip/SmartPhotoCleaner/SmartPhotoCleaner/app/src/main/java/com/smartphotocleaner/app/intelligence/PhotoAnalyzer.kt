package com.smartphotocleaner.app.intelligence

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.util.Size
import com.smartphotocleaner.app.data.PhotoIndexDatabase
import com.smartphotocleaner.app.model.GlobalSummary
import com.smartphotocleaner.app.model.IndexedPhoto
import com.smartphotocleaner.app.model.PhotoItem
import com.smartphotocleaner.app.model.UserDecision
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.yield
import kotlinx.coroutines.withContext
import java.security.MessageDigest

/**
 * Orchestrates incremental page indexing into PhotoIndexDatabase with:
 * - Adaptive 1-2 worker throttling via ResourceController
 * - Transactional 50-photo checkpoints
 * - EXIF orientation normalization
 * - Reused per-worker pixel buffers
 */
class PhotoAnalyzer(private val context: Context) {

    val db = PhotoIndexDatabase(context)
    private val resourceController = ResourceController(context)

    companion object {
        private const val CHECKPOINT_BATCH_SIZE = 50
    }

    private class WorkerBuffers {
        val dHashPixels = IntArray(9 * 8)
        val colorPixels = IntArray(16)
        val gridPixels = IntArray(ImageQualityEngine.ANALYSIS_GRID * ImageQualityEngine.ANALYSIS_GRID)
        val gray = DoubleArray(ImageQualityEngine.ANALYSIS_GRID * ImageQualityEngine.ANALYSIS_GRID)
    }

    suspend fun indexPageIncremental(
        photos: List<PhotoItem>,
        totalGalleryCount: Int,
        onProgress: (processedInPage: Int, pageSize: Int, mode: ResourceMode, partialSummary: GlobalSummary) -> Unit
    ): GlobalSummary = withContext(Dispatchers.Default) {
        val pageSize = photos.size
        val existing = withContext(Dispatchers.IO) {
            db.getExistingSignatures(photos.map { it.id })
        }

        val toAnalyze = photos.filter { item ->
            val sig = existing[item.id]
            sig == null || sig.first != item.sizeBytes || sig.second != item.modifiedTimeSeconds
        }

        var processed = pageSize - toAnalyze.size
        if (processed > 0) {
            val summary = buildGlobalSummary(totalGalleryCount)
            onProgress(processed, pageSize, resourceController.currentMode(), summary)
        }

        for (batch in toAnalyze.chunked(CHECKPOINT_BATCH_SIZE)) {
            var activeMode = ResourceMode.NORMAL
            resourceController.awaitSafeResources { mode ->
                activeMode = mode
                if (mode == ResourceMode.PAUSED_MEMORY || mode == ResourceMode.PAUSED_THERMAL) {
                    onProgress(processed, pageSize, mode, buildGlobalSummary(totalGalleryCount))
                }
            }

            val workers = resourceController.recommendedWorkers()
            val analyzedBatch = processBatch(batch, workers)

            if (analyzedBatch.isNotEmpty()) {
                val lastId = analyzedBatch.last().mediaId
                withContext(Dispatchers.IO) {
                    db.commitAnalyzedBatch(
                        items = analyzedBatch,
                        lastMediaId = lastId,
                        processedCount = processed + batch.size,
                        scanStatus = "ANALYSING"
                    )
                }
            }

            processed = (processed + batch.size).coerceAtMost(pageSize)
            val summary = buildGlobalSummary(totalGalleryCount)
            onProgress(processed, pageSize, activeMode, summary)
            yield()
        }

        buildGlobalSummary(totalGalleryCount)
    }

    private suspend fun processBatch(batch: List<PhotoItem>, workers: Int): List<IndexedPhoto> = coroutineScope {
        if (workers <= 1) {
            val buffers = WorkerBuffers()
            batch.mapNotNull { analyzeSinglePhoto(it, buffers) }
        } else {
            val subChunks = batch.chunked((batch.size + workers - 1) / workers)
            subChunks.map { sub ->
                async(Dispatchers.Default) {
                    val buffers = WorkerBuffers()
                    sub.mapNotNull { analyzeSinglePhoto(it, buffers) }
                }
            }.awaitAll().flatten()
        }
    }

    fun buildGlobalSummary(totalGalleryCount: Int): GlobalSummary {
        val groups = db.loadSimilarGroups()
        val bad = db.loadBadPhotos()
        val indexed = db.countIndexed()
        val bytes = groups.sumOf { it.potentialSavingsBytes } + bad.sumOf { it.fileSize }
        return GlobalSummary(
            totalIndexed = indexed,
            totalGalleryCount = totalGalleryCount,
            similarGroups = groups,
            badPhotos = bad,
            totalSuggestedBytes = bytes
        )
    }

    fun computeSha256(uri: Uri): String? {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val buffer = ByteArray(8192)
                var read = stream.read(buffer)
                while (read != -1) {
                    digest.update(buffer, 0, read)
                    read = stream.read(buffer)
                }
            } ?: return null
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            null
        }
    }

    fun setDecision(mediaIds: List<Long>, decision: UserDecision) {
        db.setDecisions(mediaIds, decision)
    }

    fun resetKeptDecisions() {
        db.resetKeptDecisions()
    }

    fun removeDeleted(mediaIds: List<Long>) {
        db.removeMediaIds(mediaIds)
    }

    fun reconcileAccessible(accessibleIds: Set<Long>) {
        db.reconcileDeletedIds(accessibleIds)
    }

    private fun analyzeSinglePhoto(item: PhotoItem, buffers: WorkerBuffers): IndexedPhoto? {
        val bitmap = loadOrientedThumbnail(item) ?: return null
        return try {
            val dHashScaled = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
            try {
                dHashScaled.getPixels(buffers.dHashPixels, 0, 9, 0, 0, 9, 8)
            } finally {
                if (dHashScaled !== bitmap) dHashScaled.recycle()
            }
            val dHash = ImageQualityEngine.computeDHashFromLuminance(buffers.dHashPixels)

            val colorScaled = Bitmap.createScaledBitmap(bitmap, 4, 4, true)
            try {
                colorScaled.getPixels(buffers.colorPixels, 0, 4, 0, 0, 4, 4)
            } finally {
                if (colorScaled !== bitmap) colorScaled.recycle()
            }
            val colorSig = ImageQualityEngine.computeColorSignatureFrom4x4(buffers.colorPixels)

            val gridSize = ImageQualityEngine.ANALYSIS_GRID
            val gridScaled = Bitmap.createScaledBitmap(bitmap, gridSize, gridSize, true)
            try {
                gridScaled.getPixels(buffers.gridPixels, 0, gridSize, 0, 0, gridSize, gridSize)
            } finally {
                if (gridScaled !== bitmap) gridScaled.recycle()
            }
            val metrics = ImageQualityEngine.evaluateQualityFromGrid(buffers.gridPixels, buffers.gray, gridSize)
            val reasons = ImageQualityEngine.classifyReasons(metrics, item.width, item.height)
            val qualityScore = ImageQualityEngine.calculateQualityScore(metrics, item.width, item.height)

            IndexedPhoto(
                mediaId = item.id,
                uri = item.uri,
                displayName = item.displayName,
                volumeName = item.volumeName,
                dHash = dHash,
                colorSignature = colorSig,
                width = item.width,
                height = item.height,
                brightness = metrics.meanBrightness,
                sharpness = metrics.regionalSharpness,
                gradientEntropy = metrics.gradientEntropy,
                fileSize = item.sizeBytes,
                modifiedTime = item.modifiedTimeSeconds,
                qualityScore = qualityScore,
                reasons = reasons,
                scanVersion = ImageQualityEngine.SCAN_VERSION
            )
        } finally {
            bitmap.recycle()
        }
    }

    private fun loadOrientedThumbnail(item: PhotoItem): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                context.contentResolver.loadThumbnail(item.uri, Size(128, 128), null)
            } else {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(item.uri)?.use {
                    BitmapFactory.decodeStream(it, null, bounds)
                }
                val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
                if (maxDim <= 0) return null
                val sampleSize = if (maxDim > 128) maxDim / 128 else 1
                val decodeOpts = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize.coerceAtLeast(1)
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                val raw = context.contentResolver.openInputStream(item.uri)?.use {
                    BitmapFactory.decodeStream(it, null, decodeOpts)
                } ?: return null

                val rotation = readExifRotation(item.uri)
                if (rotation == 0f) raw else {
                    val matrix = Matrix().apply { postRotate(rotation) }
                    val rotated = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
                    if (rotated !== raw) raw.recycle()
                    rotated
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun readExifRotation(uri: Uri): Float {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val exif = ExifInterface(stream)
                when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (_: Exception) {
            0f
        }
    }
}
