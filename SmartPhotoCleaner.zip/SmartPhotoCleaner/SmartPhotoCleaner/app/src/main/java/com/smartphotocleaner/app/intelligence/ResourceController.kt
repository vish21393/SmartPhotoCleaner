package com.smartphotocleaner.app.intelligence

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import kotlinx.coroutines.delay

enum class ResourceMode {
    NORMAL,
    THROTTLED_SINGLE_WORKER,
    PAUSED_MEMORY,
    PAUSED_THERMAL
}

/**
 * Independently monitors system + JVM heap memory and Android thermal status
 * to keep constrained (<1 GB free RAM, older CPU) devices responsive.
 */
class ResourceController(private val context: Context) {

    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager

    fun currentMode(): ResourceMode {
        if (isMemoryCritical()) return ResourceMode.PAUSED_MEMORY
        if (isThermalCritical()) return ResourceMode.PAUSED_THERMAL
        if (isThermalModerate() || isMemoryModerate()) return ResourceMode.THROTTLED_SINGLE_WORKER
        return ResourceMode.NORMAL
    }

    fun recommendedWorkers(): Int {
        return when (currentMode()) {
            ResourceMode.NORMAL -> if (activityManager?.isLowRamDevice == true) 1 else 2
            ResourceMode.THROTTLED_SINGLE_WORKER -> 1
            ResourceMode.PAUSED_MEMORY, ResourceMode.PAUSED_THERMAL -> 1
        }
    }

    suspend fun awaitSafeResources(onStatus: (ResourceMode) -> Unit) {
        var mode = currentMode()
        while (mode == ResourceMode.PAUSED_MEMORY || mode == ResourceMode.PAUSED_THERMAL) {
            onStatus(mode)
            delay(1500L)
            mode = currentMode()
        }
        onStatus(mode)
    }

    private fun isMemoryCritical(): Boolean {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memInfo)
        val lowSysMem = memInfo.lowMemory || memInfo.availMem < 120L * 1024L * 1024L

        val rt = Runtime.getRuntime()
        val usedHeap = rt.totalMemory() - rt.freeMemory()
        val heapRatio = usedHeap.toDouble() / rt.maxMemory().toDouble()
        return lowSysMem || heapRatio > 0.88
    }

    private fun isMemoryModerate(): Boolean {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memInfo)
        return activityManager?.isLowRamDevice == true || memInfo.availMem < 350L * 1024L * 1024L
    }

    private fun isThermalCritical(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val status = powerManager?.currentThermalStatus ?: return false
        return status >= PowerManager.THERMAL_STATUS_SEVERE
    }

    private fun isThermalModerate(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val status = powerManager?.currentThermalStatus ?: return false
        return status >= PowerManager.THERMAL_STATUS_MODERATE
    }
}
