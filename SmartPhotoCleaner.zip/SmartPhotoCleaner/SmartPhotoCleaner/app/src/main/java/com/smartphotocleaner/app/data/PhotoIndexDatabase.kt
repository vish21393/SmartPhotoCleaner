package com.smartphotocleaner.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import com.smartphotocleaner.app.intelligence.ImageQualityEngine
import com.smartphotocleaner.app.model.BadPhotoReason
import com.smartphotocleaner.app.model.IndexedPhoto
import com.smartphotocleaner.app.model.SimilarGroupView
import com.smartphotocleaner.app.model.UserDecision

/**
 * Central SQLite Intelligence Layer (v3):
 * - PhotoIndex: global fingerprints & quality metrics
 * - HashBuckets: 8x 8-bit dHash segments for cross-page candidate lookup
 * - SimilarGroups & GroupMembers: persistent incremental groups with stable anchor_photo_id
 * - PhotoDecisions: persistent KEEP / EXCLUDE / DELETED decisions independent of scan_version
 * - ScanState & AlgorithmMetadata: transactional checkpoints & algorithm versioning
 */
class PhotoIndexDatabase(context: Context) : SQLiteOpenHelper(context, "photo_scan_cache.db", null, 3) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.enableWriteAheadLogging()
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        createV3Schema(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 3) {
            createV3Schema(db)
            // Preserve user's KEEP decisions from v1.3.0 (photo_cache.ignored == 1)
            val hasOld = db.rawQuery(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='photo_cache'",
                null
            ).use { it.moveToFirst() }
            if (hasOld) {
                db.execSQL(
                    "INSERT OR IGNORE INTO PhotoDecisions (media_id, decision, updated_at) " +
                        "SELECT id, 'KEEP', strftime('%s','now') FROM photo_cache WHERE ignored = 1"
                )
                db.execSQL("DROP TABLE IF EXISTS photo_cache")
            }
        }
    }

    private fun createV3Schema(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS PhotoIndex (" +
                "media_id INTEGER PRIMARY KEY, " +
                "uri TEXT NOT NULL, " +
                "display_name TEXT NOT NULL, " +
                "volume_name TEXT NOT NULL, " +
                "d_hash INTEGER NOT NULL, " +
                "color_signature TEXT NOT NULL, " +
                "width INTEGER NOT NULL, " +
                "height INTEGER NOT NULL, " +
                "brightness REAL NOT NULL, " +
                "sharpness REAL NOT NULL, " +
                "gradient_entropy REAL NOT NULL, " +
                "file_size INTEGER NOT NULL, " +
                "modified_time INTEGER NOT NULL, " +
                "quality_score INTEGER NOT NULL, " +
                "reasons_mask INTEGER NOT NULL, " +
                "scan_version INTEGER NOT NULL)"
        )

        db.execSQL(
            "CREATE TABLE IF NOT EXISTS HashBuckets (" +
                "bucket_index INTEGER NOT NULL, " +
                "bucket_value INTEGER NOT NULL, " +
                "media_id INTEGER NOT NULL, " +
                "PRIMARY KEY (bucket_index, bucket_value, media_id), " +
                "FOREIGN KEY (media_id) REFERENCES PhotoIndex(media_id) ON DELETE CASCADE)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_hash_buckets_lookup ON HashBuckets(bucket_index, bucket_value)")

        db.execSQL(
            "CREATE TABLE IF NOT EXISTS SimilarGroups (" +
                "group_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "anchor_photo_id INTEGER NOT NULL UNIQUE, " +
                "best_photo_id INTEGER NOT NULL)"
        )

        db.execSQL(
            "CREATE TABLE IF NOT EXISTS GroupMembers (" +
                "group_id INTEGER NOT NULL, " +
                "media_id INTEGER NOT NULL UNIQUE, " +
                "PRIMARY KEY (group_id, media_id), " +
                "FOREIGN KEY (group_id) REFERENCES SimilarGroups(group_id) ON DELETE CASCADE, " +
                "FOREIGN KEY (media_id) REFERENCES PhotoIndex(media_id) ON DELETE CASCADE)"
        )

        db.execSQL(
            "CREATE TABLE IF NOT EXISTS PhotoDecisions (" +
                "media_id INTEGER PRIMARY KEY, " +
                "decision TEXT NOT NULL, " +
                "updated_at INTEGER NOT NULL)"
        )

        db.execSQL(
            "CREATE TABLE IF NOT EXISTS ScanState (" +
                "id INTEGER PRIMARY KEY CHECK (id = 1), " +
                "last_media_id INTEGER NOT NULL, " +
                "scan_generation INTEGER NOT NULL, " +
                "processed_count INTEGER NOT NULL, " +
                "status TEXT NOT NULL)"
        )

        db.execSQL(
            "CREATE TABLE IF NOT EXISTS AlgorithmMetadata (" +
                "key TEXT PRIMARY KEY, " +
                "value TEXT NOT NULL)"
        )
        db.execSQL(
            "INSERT OR REPLACE INTO AlgorithmMetadata (key, value) VALUES ('scan_version', '${ImageQualityEngine.SCAN_VERSION}')"
        )
    }

    fun getExistingSignatures(mediaIds: List<Long>): Map<Long, Pair<Long, Long>> {
        val map = HashMap<Long, Pair<Long, Long>>(mediaIds.size)
        for (chunk in mediaIds.chunked(400)) {
            val placeholders = chunk.joinToString(",") { "?" }
            val args = chunk.map { it.toString() }.toTypedArray()
            readableDatabase.rawQuery(
                "SELECT media_id, file_size, modified_time, scan_version FROM PhotoIndex WHERE media_id IN ($placeholders)",
                args
            ).use { c ->
                while (c.moveToNext()) {
                    if (c.getInt(3) == ImageQualityEngine.SCAN_VERSION) {
                        map[c.getLong(0)] = c.getLong(1) to c.getLong(2)
                    }
                }
            }
        }
        return map
    }

    fun getUserDecisions(mediaIds: List<Long>): Map<Long, UserDecision> {
        val map = HashMap<Long, UserDecision>()
        for (chunk in mediaIds.chunked(400)) {
            val placeholders = chunk.joinToString(",") { "?" }
            val args = chunk.map { it.toString() }.toTypedArray()
            readableDatabase.rawQuery(
                "SELECT media_id, decision FROM PhotoDecisions WHERE media_id IN ($placeholders)",
                args
            ).use { c ->
                while (c.moveToNext()) {
                    val dec = runCatching { UserDecision.valueOf(c.getString(1)) }.getOrDefault(UserDecision.AUTO)
                    map[c.getLong(0)] = dec
                }
            }
        }
        return map
    }

    fun setDecisions(mediaIds: List<Long>, decision: UserDecision) {
        if (mediaIds.isEmpty()) return
        val now = System.currentTimeMillis() / 1000L
        val db = writableDatabase
        db.beginTransaction()
        try {
            val cv = ContentValues()
            for (id in mediaIds) {
                cv.clear()
                cv.put("media_id", id)
                cv.put("decision", decision.name)
                cv.put("updated_at", now)
                db.insertWithOnConflict("PhotoDecisions", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            }
            if (decision == UserDecision.KEEP || decision == UserDecision.EXCLUDE || decision == UserDecision.DELETED) {
                for (chunk in mediaIds.chunked(400)) {
                    val placeholders = chunk.joinToString(",") { "?" }
                    val args = chunk.map { it.toString() }.toTypedArray()
                    db.delete("GroupMembers", "media_id IN ($placeholders)", args)
                }
                cleanupTinyGroups(db)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun resetKeptDecisions() {
        writableDatabase.execSQL("DELETE FROM PhotoDecisions WHERE decision IN ('KEEP', 'EXCLUDE')")
    }

    /**
     * Transactional batch commit: inserts PhotoIndex + 8 HashBuckets + incremental groups + ScanState checkpoint.
     */
    fun commitAnalyzedBatch(
        items: List<IndexedPhoto>,
        lastMediaId: Long,
        processedCount: Int,
        scanStatus: String
    ) {
        if (items.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            val photoCv = ContentValues()
            val bucketCv = ContentValues()

            for (item in items) {
                photoCv.clear()
                photoCv.put("media_id", item.mediaId)
                photoCv.put("uri", item.uri.toString())
                photoCv.put("display_name", item.displayName)
                photoCv.put("volume_name", item.volumeName)
                photoCv.put("d_hash", item.dHash)
                photoCv.put("color_signature", item.colorSignature.joinToString(","))
                photoCv.put("width", item.width)
                photoCv.put("height", item.height)
                photoCv.put("brightness", item.brightness)
                photoCv.put("sharpness", item.sharpness)
                photoCv.put("gradient_entropy", item.gradientEntropy)
                photoCv.put("file_size", item.fileSize)
                photoCv.put("modified_time", item.modifiedTime)
                photoCv.put("quality_score", item.qualityScore)
                photoCv.put("reasons_mask", encodeReasons(item.reasons))
                photoCv.put("scan_version", item.scanVersion)
                db.insertWithOnConflict("PhotoIndex", null, photoCv, SQLiteDatabase.CONFLICT_REPLACE)

                // Replace buckets for this photo
                db.delete("HashBuckets", "media_id = ?", arrayOf(item.mediaId.toString()))
                val buckets = ImageQualityEngine.extractBuckets(item.dHash)
                for (bIdx in 0 until 8) {
                    bucketCv.clear()
                    bucketCv.put("bucket_index", bIdx)
                    bucketCv.put("bucket_value", buckets[bIdx])
                    bucketCv.put("media_id", item.mediaId)
                    db.insertWithOnConflict("HashBuckets", null, bucketCv, SQLiteDatabase.CONFLICT_IGNORE)
                }

                // Incremental cross-page grouping
                insertIntoIncrementalGroup(db, item)
            }

            // Update ScanState checkpoint inside the same transaction
            val stateCv = ContentValues().apply {
                put("id", 1)
                put("last_media_id", lastMediaId)
                put("scan_generation", ImageQualityEngine.SCAN_VERSION)
                put("processed_count", processedCount)
                put("status", scanStatus)
            }
            db.insertWithOnConflict("ScanState", null, stateCv, SQLiteDatabase.CONFLICT_REPLACE)

            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun insertIntoIncrementalGroup(db: SQLiteDatabase, item: IndexedPhoto) {
        // Skip if user explicitly kept/excluded this photo
        val decision = db.rawQuery(
            "SELECT decision FROM PhotoDecisions WHERE media_id = ?",
            arrayOf(item.mediaId.toString())
        ).use { c -> if (c.moveToFirst()) c.getString(0) else "AUTO" }
        if (decision != "AUTO") return

        // 1. Retrieve deduplicated candidate IDs from the 8 hash buckets
        val buckets = ImageQualityEngine.extractBuckets(item.dHash)
        val candidateIds = LinkedHashSet<Long>()
        for (bIdx in 0 until 8) {
            db.rawQuery(
                "SELECT media_id FROM HashBuckets WHERE bucket_index = ? AND bucket_value = ? AND media_id != ?",
                arrayOf(bIdx.toString(), buckets[bIdx].toString(), item.mediaId.toString())
            ).use { c ->
                while (c.moveToNext()) {
                    candidateIds.add(c.getLong(0))
                }
            }
        }
        if (candidateIds.isEmpty()) return

        // 2. Load candidate records (excluding KEEP/EXCLUDE/DELETED)
        val candidates = loadIndexedByIds(db, candidateIds.toList(), excludeDecided = true)
        if (candidates.isEmpty()) return

        // 3. Check if any matching candidate is already in a group; verify against that group's anchor!
        for (cand in candidates) {
            if (!ImageQualityEngine.areVisuallySimilar(item, cand)) continue

            val existingGroupId = db.rawQuery(
                "SELECT group_id FROM GroupMembers WHERE media_id = ?",
                arrayOf(cand.mediaId.toString())
            ).use { c -> if (c.moveToFirst()) c.getLong(0) else null }

            if (existingGroupId != null) {
                val anchorAndBest = db.rawQuery(
                    "SELECT anchor_photo_id, best_photo_id FROM SimilarGroups WHERE group_id = ?",
                    arrayOf(existingGroupId.toString())
                ).use { c -> if (c.moveToFirst()) c.getLong(0) to c.getLong(1) else null }

                if (anchorAndBest != null) {
                    val (anchorId, bestId) = anchorAndBest
                    val anchorPhoto = loadIndexedByIds(db, listOf(anchorId), excludeDecided = false).firstOrNull()
                    if (anchorPhoto != null && ImageQualityEngine.areVisuallySimilar(item, anchorPhoto)) {
                        val memberCv = ContentValues().apply {
                            put("group_id", existingGroupId)
                            put("media_id", item.mediaId)
                        }
                        db.insertWithOnConflict("GroupMembers", null, memberCv, SQLiteDatabase.CONFLICT_IGNORE)

                        // Update best_photo_id independently without mutating anchor_photo_id
                        val bestPhoto = loadIndexedByIds(db, listOf(bestId), excludeDecided = false).firstOrNull()
                        if (bestPhoto == null || item.qualityScore > bestPhoto.qualityScore) {
                            val upd = ContentValues().apply { put("best_photo_id", item.mediaId) }
                            db.update("SimilarGroups", upd, "group_id = ?", arrayOf(existingGroupId.toString()))
                        }
                        return
                    }
                }
            } else {
                // Neither is in a group yet: create a new group with higher-quality photo as stable anchor
                val (anchor, other) = if (item.qualityScore >= cand.qualityScore) item to cand else cand to item
                val groupCv = ContentValues().apply {
                    put("anchor_photo_id", anchor.mediaId)
                    put("best_photo_id", anchor.mediaId)
                }
                val newGroupId = db.insertWithOnConflict("SimilarGroups", null, groupCv, SQLiteDatabase.CONFLICT_IGNORE)
                if (newGroupId > 0) {
                    val m1 = ContentValues().apply { put("group_id", newGroupId); put("media_id", anchor.mediaId) }
                    val m2 = ContentValues().apply { put("group_id", newGroupId); put("media_id", other.mediaId) }
                    db.insertWithOnConflict("GroupMembers", null, m1, SQLiteDatabase.CONFLICT_IGNORE)
                    db.insertWithOnConflict("GroupMembers", null, m2, SQLiteDatabase.CONFLICT_IGNORE)
                    return
                }
            }
        }
    }

    fun loadSimilarGroups(limit: Int = 200): List<SimilarGroupView> {
        val db = readableDatabase
        val groups = mutableListOf<SimilarGroupView>()

        db.rawQuery(
            "SELECT g.group_id, g.anchor_photo_id, g.best_photo_id FROM SimilarGroups g " +
                "JOIN GroupMembers m ON g.group_id = m.group_id " +
                "GROUP BY g.group_id HAVING COUNT(m.media_id) >= 2 " +
                "ORDER BY g.group_id DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { gc ->
            while (gc.moveToNext()) {
                val groupId = gc.getLong(0)
                val anchorId = gc.getLong(1)
                val bestId = gc.getLong(2)

                val memberIds = mutableListOf<Long>()
                db.rawQuery(
                    "SELECT media_id FROM GroupMembers WHERE group_id = ?",
                    arrayOf(groupId.toString())
                ).use { mc ->
                    while (mc.moveToNext()) memberIds.add(mc.getLong(0))
                }

                val members = loadIndexedByIds(db, memberIds, excludeDecided = true)
                if (members.size >= 2) {
                    val sorted = members.sortedByDescending { it.qualityScore }
                    val best = sorted.firstOrNull { it.mediaId == bestId } ?: sorted.first()
                    val others = sorted.filter { it.mediaId != best.mediaId }.map {
                        if (BadPhotoReason.DUPLICATE_OF_BETTER in it.reasons) it
                        else it.copy(reasons = it.reasons + BadPhotoReason.DUPLICATE_OF_BETTER)
                    }
                    val hasExact = others.any {
                        it.fileSize == best.fileSize && it.width == best.width && it.height == best.height
                    }
                    groups.add(
                        SimilarGroupView(
                            groupId = groupId,
                            anchorPhotoId = anchorId,
                            bestPhoto = best,
                            candidatesToDelete = others,
                            hasExactDuplicates = hasExact
                        )
                    )
                }
            }
        }
        return groups
    }

    fun loadBadPhotos(limit: Int = 300): List<IndexedPhoto> {
        val db = readableDatabase
        val bad = mutableListOf<IndexedPhoto>()
        db.rawQuery(
            "SELECT p.* FROM PhotoIndex p " +
                "LEFT JOIN PhotoDecisions d ON p.media_id = d.media_id " +
                "LEFT JOIN GroupMembers m ON p.media_id = m.media_id " +
                "WHERE p.reasons_mask > 0 " +
                "AND (d.decision IS NULL OR d.decision = 'AUTO') " +
                "AND m.media_id IS NULL " +
                "ORDER BY p.quality_score ASC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                bad.add(cursorToIndexedPhoto(c))
            }
        }
        return bad
    }

    fun countIndexed(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM PhotoIndex", null).use { c ->
            return if (c.moveToFirst()) c.getInt(0) else 0
        }
    }

    fun reconcileDeletedIds(accessibleIds: Set<Long>) {
        val db = writableDatabase
        val staleIds = mutableListOf<Long>()
        db.rawQuery("SELECT media_id FROM PhotoIndex", null).use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                if (id !in accessibleIds) staleIds.add(id)
            }
        }
        if (staleIds.isNotEmpty()) {
            removeMediaIds(staleIds)
        }
    }

    fun removeMediaIds(ids: List<Long>) {
        if (ids.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (chunk in ids.chunked(400)) {
                val placeholders = chunk.joinToString(",") { "?" }
                val args = chunk.map { it.toString() }.toTypedArray()
                db.delete("PhotoIndex", "media_id IN ($placeholders)", args)
            }
            cleanupTinyGroups(db)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun cleanupTinyGroups(db: SQLiteDatabase) {
        db.execSQL(
            "DELETE FROM SimilarGroups WHERE group_id IN (" +
                "SELECT g.group_id FROM SimilarGroups g " +
                "LEFT JOIN GroupMembers m ON g.group_id = m.group_id " +
                "GROUP BY g.group_id HAVING COUNT(m.media_id) < 2)"
        )
    }

    private fun loadIndexedByIds(
        db: SQLiteDatabase,
        ids: List<Long>,
        excludeDecided: Boolean
    ): List<IndexedPhoto> {
        if (ids.isEmpty()) return emptyList()
        val list = mutableListOf<IndexedPhoto>()
        for (chunk in ids.chunked(400)) {
            val placeholders = chunk.joinToString(",") { "?" }
            val args = chunk.map { it.toString() }.toTypedArray()
            val sql = if (excludeDecided) {
                "SELECT p.* FROM PhotoIndex p LEFT JOIN PhotoDecisions d ON p.media_id = d.media_id " +
                    "WHERE p.media_id IN ($placeholders) AND (d.decision IS NULL OR d.decision = 'AUTO')"
            } else {
                "SELECT * FROM PhotoIndex WHERE media_id IN ($placeholders)"
            }
            db.rawQuery(sql, args).use { c ->
                while (c.moveToNext()) {
                    list.add(cursorToIndexedPhoto(c))
                }
            }
        }
        return list
    }

    private fun cursorToIndexedPhoto(c: android.database.Cursor): IndexedPhoto {
        val sigParts = c.getString(c.getColumnIndexOrThrow("color_signature")).split(",")
        val sig = IntArray(48) { idx -> sigParts.getOrNull(idx)?.toIntOrNull() ?: 0 }
        return IndexedPhoto(
            mediaId = c.getLong(c.getColumnIndexOrThrow("media_id")),
            uri = Uri.parse(c.getString(c.getColumnIndexOrThrow("uri"))),
            displayName = c.getString(c.getColumnIndexOrThrow("display_name")),
            volumeName = c.getString(c.getColumnIndexOrThrow("volume_name")),
            dHash = c.getLong(c.getColumnIndexOrThrow("d_hash")),
            colorSignature = sig,
            width = c.getInt(c.getColumnIndexOrThrow("width")),
            height = c.getInt(c.getColumnIndexOrThrow("height")),
            brightness = c.getDouble(c.getColumnIndexOrThrow("brightness")),
            sharpness = c.getDouble(c.getColumnIndexOrThrow("sharpness")),
            gradientEntropy = c.getDouble(c.getColumnIndexOrThrow("gradient_entropy")),
            fileSize = c.getLong(c.getColumnIndexOrThrow("file_size")),
            modifiedTime = c.getLong(c.getColumnIndexOrThrow("modified_time")),
            qualityScore = c.getInt(c.getColumnIndexOrThrow("quality_score")),
            reasons = decodeReasons(c.getInt(c.getColumnIndexOrThrow("reasons_mask"))),
            scanVersion = c.getInt(c.getColumnIndexOrThrow("scan_version"))
        )
    }

    companion object {
        fun encodeReasons(reasons: List<BadPhotoReason>): Int {
            var mask = 0
            for (r in reasons) {
                if (r != BadPhotoReason.DUPLICATE_OF_BETTER && r != BadPhotoReason.EXACT_DUPLICATE) {
                    mask = mask or (1 shl r.ordinal)
                }
            }
            return mask
        }

        fun decodeReasons(mask: Int): List<BadPhotoReason> {
            val list = mutableListOf<BadPhotoReason>()
            for (r in BadPhotoReason.entries) {
                if (r != BadPhotoReason.DUPLICATE_OF_BETTER &&
                    r != BadPhotoReason.EXACT_DUPLICATE &&
                    (mask and (1 shl r.ordinal)) != 0
                ) {
                    list.add(r)
                }
            }
            return list
        }
    }
}
