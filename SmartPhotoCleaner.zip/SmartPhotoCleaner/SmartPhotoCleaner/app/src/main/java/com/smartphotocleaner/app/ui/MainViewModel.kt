package com.smartphotocleaner.app.ui

import android.app.Application
import android.app.PendingIntent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartphotocleaner.app.data.MediaStoreRepository
import com.smartphotocleaner.app.intelligence.PhotoAnalyzer
import com.smartphotocleaner.app.model.ScanSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MainUiState(
    val isScanning: Boolean = false,
    val scanProcessed: Int = 0,
    val scanTotal: Int = 0,
    val summary: ScanSummary = ScanSummary(),
    val selectedUris: Set<Uri> = emptySet(),
    val statusMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MediaStoreRepository(application)
    private val analyzer = PhotoAnalyzer(application)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    fun startScan() {
        if (_uiState.value.isScanning) return

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isScanning = true,
                    scanProcessed = 0,
                    scanTotal = 0,
                    statusMessage = null
                )
            }

            val photos = repository.loadAllPhotos()
            if (photos.isEmpty()) {
                _uiState.update {
                    it.copy(
                        isScanning = false,
                        summary = ScanSummary(),
                        selectedUris = emptySet(),
                        statusMessage = "No photos found on this device."
                    )
                }
                return@launch
            }

            val summary = analyzer.analyzeGallery(photos) { processed, total ->
                _uiState.update {
                    it.copy(scanProcessed = processed, scanTotal = total)
                }
            }

            val defaultSelected = buildSet {
                summary.similarGroups.forEach { group ->
                    group.candidatesToDelete.forEach { add(it.photo.uri) }
                }
                summary.badPhotos.forEach { add(it.photo.uri) }
            }

            _uiState.update {
                it.copy(
                    isScanning = false,
                    summary = summary,
                    selectedUris = defaultSelected,
                    statusMessage = "Scanned ${summary.totalScanned} photos."
                )
            }
        }
    }

    fun toggleSelection(uri: Uri) {
        _uiState.update { state ->
            val updated = state.selectedUris.toMutableSet()
            if (!updated.add(uri)) {
                updated.remove(uri)
            }
            state.copy(selectedUris = updated)
        }
    }

    fun selectAllSuggested() {
        val summary = _uiState.value.summary
        val suggested = buildSet {
            summary.similarGroups.forEach { g -> g.candidatesToDelete.forEach { add(it.photo.uri) } }
            summary.badPhotos.forEach { add(it.photo.uri) }
        }
        _uiState.update { it.copy(selectedUris = suggested) }
    }

    fun clearSelection() {
        _uiState.update { it.copy(selectedUris = emptySet()) }
    }

    fun createDeletePendingIntent(uris: List<Uri> = _uiState.value.selectedUris.toList()): PendingIntent? {
        return repository.createDeleteRequest(uris)
    }

    fun deleteLegacy(uris: List<Uri> = _uiState.value.selectedUris.toList()) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val count = repository.deleteLegacy(uris)
            _uiState.update { it.copy(statusMessage = "Deleted $count photos.") }
            startScan()
        }
    }

    fun onDeleteRequestCompleted(success: Boolean) {
        if (success) {
            _uiState.update { it.copy(statusMessage = "Selected photos deleted.") }
            startScan()
        } else {
            _uiState.update { it.copy(statusMessage = "Deletion cancelled.") }
        }
    }

    fun selectedBytes(): Long {
        val selected = _uiState.value.selectedUris
        val summary = _uiState.value.summary
        val all = (summary.similarGroups.flatMap { it.allPhotos } + summary.badPhotos)
            .associateBy { it.photo.uri }
        return selected.sumOf { all[it]?.photo?.sizeBytes ?: 0L }
    }
}
