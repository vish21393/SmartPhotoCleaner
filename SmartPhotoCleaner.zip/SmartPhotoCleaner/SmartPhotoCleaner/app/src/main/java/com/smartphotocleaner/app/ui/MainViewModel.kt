package com.smartphotocleaner.app.ui

import android.app.Application
import android.app.PendingIntent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartphotocleaner.app.data.MediaStoreRepository
import com.smartphotocleaner.app.intelligence.PhotoAnalyzer
import com.smartphotocleaner.app.intelligence.ResourceMode
import com.smartphotocleaner.app.model.GlobalSummary
import com.smartphotocleaner.app.model.IndexedPhoto
import com.smartphotocleaner.app.model.SimilarGroupView
import com.smartphotocleaner.app.model.UserDecision
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MainUiState(
    val isScanning: Boolean = false,
    val resourceMode: ResourceMode = ResourceMode.NORMAL,
    val scanProcessedInPage: Int = 0,
    val scanPageSize: Int = 0,
    val currentPage: Int = 0,
    val pageSize: Int = 1000,
    val summary: GlobalSummary = GlobalSummary(),
    val selectedUris: Set<Uri> = emptySet(),
    val isPartialAccess: Boolean = false,
    val exactDupCheckResult: String? = null,
    val statusMessage: String? = null
) {
    val totalPages: Int
        get() = if (summary.totalGalleryCount == 0) 1 else (summary.totalGalleryCount + pageSize - 1) / pageSize
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MediaStoreRepository(application)
    private val analyzer = PhotoAnalyzer(application)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var pendingDeleteItems: List<IndexedPhoto> = emptyList()
    private var scanJob: Job? = null

    fun setPartialAccess(partial: Boolean) {
        _uiState.update { it.copy(isPartialAccess = partial) }
    }

    fun scanPage(pageIndex: Int = _uiState.value.currentPage) {
        scanJob?.cancel()
        val targetPage = pageIndex.coerceAtLeast(0)
        val pageSize = _uiState.value.pageSize

        scanJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isScanning = true,
                    currentPage = targetPage,
                    scanProcessedInPage = 0,
                    scanPageSize = 0,
                    statusMessage = null
                )
            }

            // On full access page 0, reconcile externally deleted files
            if (targetPage == 0 && !_uiState.value.isPartialAccess) {
                val accessibleIds = repository.loadAllAccessibleIds()
                analyzer.reconcileAccessible(accessibleIds)
            }

            val (photos, totalCount) = repository.loadPhotoMetadataPage(
                offset = targetPage * pageSize,
                pageSize = pageSize
            )

            if (photos.isEmpty()) {
                val summary = analyzer.buildGlobalSummary(totalCount)
                _uiState.update {
                    it.copy(
                        isScanning = false,
                        summary = summary,
                        statusMessage = "No photos on this page."
                    )
                }
                return@launch
            }

            _uiState.update { it.copy(scanPageSize = photos.size) }

            val finalSummary = analyzer.indexPageIncremental(photos, totalCount) { processed, totalInPage, mode, partial ->
                _uiState.update { state ->
                    state.copy(
                        scanProcessedInPage = processed,
                        scanPageSize = totalInPage,
                        resourceMode = mode,
                        summary = partial,
                        selectedUris = mergeSuggestedSelection(state.selectedUris, partial)
                    )
                }
            }

            _uiState.update { state ->
                state.copy(
                    isScanning = false,
                    summary = finalSummary,
                    selectedUris = mergeSuggestedSelection(state.selectedUris, finalSummary),
                    statusMessage = "Indexed page ${targetPage + 1} (${finalSummary.totalIndexed} total in global index)."
                )
            }
        }
    }

    fun nextPage() {
        val state = _uiState.value
        if (state.currentPage + 1 < state.totalPages) {
            scanPage(state.currentPage + 1)
        }
    }

    fun prevPage() {
        val state = _uiState.value
        if (state.currentPage > 0) {
            scanPage(state.currentPage - 1)
        }
    }

    fun keepGroupIntact(group: SimilarGroupView) {
        val ids = group.allPhotos.map { it.mediaId }
        val uris = group.allPhotos.map { it.uri }.toSet()

        viewModelScope.launch(Dispatchers.IO) {
            analyzer.setDecision(ids, UserDecision.KEEP)
            val updated = analyzer.buildGlobalSummary(_uiState.value.summary.totalGalleryCount)
            _uiState.update {
                it.copy(
                    summary = updated,
                    selectedUris = it.selectedUris - uris,
                    statusMessage = "Kept ${ids.size} photos permanently."
                )
            }
        }
    }

    fun keepSingleBadPhoto(photo: IndexedPhoto) {
        viewModelScope.launch(Dispatchers.IO) {
            analyzer.setDecision(listOf(photo.mediaId), UserDecision.KEEP)
            val updated = analyzer.buildGlobalSummary(_uiState.value.summary.totalGalleryCount)
            _uiState.update {
                it.copy(
                    summary = updated,
                    selectedUris = it.selectedUris - photo.uri,
                    statusMessage = "Kept ${photo.displayName}."
                )
            }
        }
    }

    fun resetKeptAndRescan() {
        viewModelScope.launch(Dispatchers.IO) {
            analyzer.resetKeptDecisions()
            scanPage(_uiState.value.currentPage)
        }
    }

    fun verifyExactDuplicate(photo: IndexedPhoto, group: SimilarGroupView?) {
        if (group == null) {
            _uiState.update { it.copy(exactDupCheckResult = null) }
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val targetHash = analyzer.computeSha256(photo.uri)
            val anchorHash = analyzer.computeSha256(group.bestPhoto.uri)
            val msg = if (targetHash != null && targetHash == anchorHash) {
                "SHA-256 Verified: Byte-for-byte exact duplicate"
            } else {
                "Visually similar (different file bytes)"
            }
            _uiState.update { it.copy(exactDupCheckResult = msg) }
        }
    }

    fun clearExactDupCheck() {
        _uiState.update { it.copy(exactDupCheckResult = null) }
    }

    private fun mergeSuggestedSelection(current: Set<Uri>, summary: GlobalSummary): Set<Uri> {
        return buildSet {
            addAll(current)
            summary.similarGroups.forEach { g ->
                g.candidatesToDelete.forEach { add(it.uri) }
            }
            summary.badPhotos.forEach { add(it.uri) }
        }
    }

    fun toggleSelection(uri: Uri) {
        _uiState.update { state ->
            val updated = state.selectedUris.toMutableSet()
            if (!updated.add(uri)) updated.remove(uri)
            state.copy(selectedUris = updated)
        }
    }

    fun selectAllSuggested() {
        val summary = _uiState.value.summary
        val suggested = buildSet {
            summary.similarGroups.forEach { g -> g.candidatesToDelete.forEach { add(it.uri) } }
            summary.badPhotos.forEach { add(it.uri) }
        }
        _uiState.update { it.copy(selectedUris = suggested) }
    }

    fun clearSelection() {
        _uiState.update { it.copy(selectedUris = emptySet()) }
    }

    fun prepareDelete(uris: List<Uri>): PendingIntent? {
        val allMap = (_uiState.value.summary.similarGroups.flatMap { it.allPhotos } + _uiState.value.summary.badPhotos)
            .associateBy { it.uri }
        val accessible = uris.filter { repository.isUriAccessible(it) }
        pendingDeleteItems = accessible.mapNotNull { allMap[it] }
        return repository.createDeleteRequest(accessible)
    }

    fun deleteLegacy(uris: List<Uri>) {
        val allMap = (_uiState.value.summary.similarGroups.flatMap { it.allPhotos } + _uiState.value.summary.badPhotos)
            .associateBy { it.uri }
        val accessible = uris.filter { repository.isUriAccessible(it) }
        val items = accessible.mapNotNull { allMap[it] }
        if (items.isEmpty()) return

        viewModelScope.launch {
            val count = repository.deleteLegacy(accessible)
            if (count > 0) {
                applyDeletion(items)
            }
            _uiState.update { it.copy(statusMessage = "Deleted $count photos.") }
        }
    }

    fun onDeleteRequestCompleted(success: Boolean) {
        val deleted = pendingDeleteItems
        pendingDeleteItems = emptyList()
        if (success && deleted.isNotEmpty()) {
            applyDeletion(deleted)
            _uiState.update { it.copy(statusMessage = "Deleted ${deleted.size} photos.") }
        } else {
            _uiState.update { it.copy(statusMessage = "Deletion cancelled.") }
        }
    }

    private fun applyDeletion(items: List<IndexedPhoto>) {
        val ids = items.map { it.mediaId }
        val uris = items.map { it.uri }.toSet()

        viewModelScope.launch(Dispatchers.IO) {
            analyzer.removeDeleted(ids)
            val newTotal = (_uiState.value.summary.totalGalleryCount - items.size).coerceAtLeast(0)
            val updated = analyzer.buildGlobalSummary(newTotal)
            _uiState.update {
                it.copy(
                    summary = updated,
                    selectedUris = it.selectedUris - uris
                )
            }
        }
    }

    fun selectedBytes(): Long {
        val selected = _uiState.value.selectedUris
        val summary = _uiState.value.summary
        val all = (summary.similarGroups.flatMap { it.allPhotos } + summary.badPhotos)
            .associateBy { it.uri }
        return selected.sumOf { all[it]?.fileSize ?: 0L }
    }
}
