package com.smartphotocleaner.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.smartphotocleaner.app.model.AnalyzedPhoto
import com.smartphotocleaner.app.model.SimilarPhotoGroup
import com.smartphotocleaner.app.ui.MainUiState
import com.smartphotocleaner.app.ui.MainViewModel
import com.smartphotocleaner.app.ui.theme.SmartPhotoCleanerTheme
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SmartPhotoCleanerTheme {
                SmartPhotoCleanerScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartPhotoCleanerScreen(viewModel: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    var previewPhoto by remember { mutableStateOf<AnalyzedPhoto?>(null) }

    val requiredPermission = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }

    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, requiredPermission) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasPermission = granted
        if (granted) {
            viewModel.startScan()
        }
    }

    val deleteLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        viewModel.onDeleteRequestCompleted(result.resultCode == Activity.RESULT_OK)
    }

    fun triggerDelete(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val intent = viewModel.createDeletePendingIntent(uris)
        if (intent != null) {
            deleteLauncher.launch(IntentSenderRequest.Builder(intent.intentSender).build())
        } else {
            viewModel.deleteLegacy(uris)
        }
    }

    LaunchedEffect(hasPermission) {
        if (hasPermission && uiState.summary.totalScanned == 0 && !uiState.isScanning) {
            viewModel.startScan()
        }
    }

    Scaffold(
        contentWindowInsets = ScaffoldDefaults.contentWindowInsets,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Smart Photo Cleaner", fontWeight = FontWeight.Bold)
                        Text(
                            "On-device similarity & quality AI",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    if (hasPermission) {
                        IconButton(onClick = { viewModel.startScan() }, enabled = !uiState.isScanning) {
                            Icon(Icons.Default.Refresh, contentDescription = "Rescan")
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (uiState.selectedUris.isNotEmpty()) {
                val mb = viewModel.selectedBytes() / (1024.0 * 1024.0)
                Surface(
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                "${uiState.selectedUris.size} selected",
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                String.format(Locale.US, "Free up %.1f MB", mb),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { viewModel.clearSelection() }) {
                                Text("Clear")
                            }
                            Button(
                                onClick = { triggerDelete(uiState.selectedUris.toList()) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (!hasPermission) {
                PermissionCard(onRequestPermission = { permissionLauncher.launch(requiredPermission) })
            } else {
                SummaryBanner(uiState = uiState, onSelectSuggested = { viewModel.selectAllSuggested() })

                if (uiState.isScanning) {
                    val progress = if (uiState.scanTotal > 0) {
                        uiState.scanProcessed.toFloat() / uiState.scanTotal.toFloat()
                    } else 0f
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                    )
                    Text(
                        "Analyzing ${uiState.scanProcessed} of ${uiState.scanTotal} photos...",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }

                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Similar (${uiState.summary.similarGroups.size})") }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Bad Photos (${uiState.summary.badPhotos.size})") }
                    )
                }

                if (selectedTab == 0) {
                    SimilarGroupsList(
                        groups = uiState.summary.similarGroups,
                        selectedUris = uiState.selectedUris,
                        onToggle = { viewModel.toggleSelection(it) },
                        onPreview = { previewPhoto = it },
                        onDeleteGroup = { uris -> triggerDelete(uris) }
                    )
                } else {
                    BadPhotosList(
                        badPhotos = uiState.summary.badPhotos,
                        selectedUris = uiState.selectedUris,
                        onToggle = { viewModel.toggleSelection(it) },
                        onPreview = { previewPhoto = it }
                    )
                }
            }
        }
    }

    previewPhoto?.let { photo ->
        FullscreenPhotoDialog(
            analyzed = photo,
            isSelected = photo.photo.uri in uiState.selectedUris,
            onToggleSelect = { viewModel.toggleSelection(photo.photo.uri) },
            onDismiss = { previewPhoto = null }
        )
    }
}

@Composable
private fun FullscreenPhotoDialog(
    analyzed: AnalyzedPhoto,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onDismiss: () -> Unit
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val transformState = rememberTransformableState { zoomChange, panChange, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 4f)
        if (scale > 1f) {
            offsetX += panChange.x
            offsetY += panChange.y
        } else {
            offsetX = 0f
            offsetY = 0f
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            AsyncImage(
                model = analyzed.photo.uri,
                contentDescription = analyzed.photo.displayName,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offsetX,
                        translationY = offsetY
                    )
                    .transformable(state = transformState)
            )

            // Top bar with close button & metadata
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color(0x99000000))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        analyzed.photo.displayName,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        String.format(
                            Locale.US,
                            "%dx%d · %.1f MB · Quality %d/100",
                            analyzed.photo.width,
                            analyzed.photo.height,
                            analyzed.photo.sizeBytes / (1024.0 * 1024.0),
                            analyzed.qualityScore
                        ),
                        color = Color.LightGray,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close preview", tint = Color.White)
                }
            }

            // Bottom bar with reasons & Select/Keep toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(Color(0xB3000000))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    if (analyzed.reasons.isNotEmpty()) {
                        analyzed.reasons.joinToString(" · ") { it.label }
                    } else {
                        "Good quality shot"
                    },
                    color = if (analyzed.reasons.isNotEmpty()) Color(0xFFFCA5A5) else Color(0xFF86EFAC),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(12.dp))
                Button(
                    onClick = onToggleSelect,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(if (isSelected) "Marked for Delete" else "Select to Delete")
                }
            }
        }
    }
}

@Composable
private fun PermissionCard(onRequestPermission: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    Icons.Default.PhotoLibrary,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(48.dp)
                )
                Text(
                    "Allow Photo Access",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Smart Photo Cleaner analyzes your photos completely on-device to find similar burst shots, blurry images, and poorly exposed photos.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(onClick = onRequestPermission, modifier = Modifier.fillMaxWidth()) {
                    Text("Grant Access & Scan")
                }
            }
        }
    }
}

@Composable
private fun SummaryBanner(uiState: MainUiState, onSelectSuggested: () -> Unit) {
    val totalMb = uiState.summary.totalSuggestedBytes / (1024.0 * 1024.0)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "${uiState.summary.totalScanned} Photos Scanned",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    String.format(Locale.US, "%.1f MB can be cleaned safely", totalMb),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            if (uiState.summary.totalSuggestedBytes > 0L) {
                FilledTonalButton(onClick = onSelectSuggested) {
                    Text("Auto-Select")
                }
            }
        }
    }
}

@Composable
private fun SimilarGroupsList(
    groups: List<SimilarPhotoGroup>,
    selectedUris: Set<Uri>,
    onToggle: (Uri) -> Unit,
    onPreview: (AnalyzedPhoto) -> Unit,
    onDeleteGroup: (List<Uri>) -> Unit
) {
    if (groups.isEmpty()) {
        EmptyState("No similar photo clusters found yet.")
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(groups, key = { it.groupId }) { group ->
            val groupSelected = group.allPhotos
                .map { it.photo.uri }
                .filter { it in selectedUris }
            val deleteTargets = groupSelected.ifEmpty {
                group.candidatesToDelete.map { it.photo.uri }
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    val savingsMb = group.potentialSavingsBytes / (1024.0 * 1024.0)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "${group.allPhotos.size} Similar Photos",
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                String.format(Locale.US, "Save %.1f MB", savingsMb),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        FilledTonalButton(
                            onClick = { onDeleteGroup(deleteTargets) },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer,
                                contentColor = MaterialTheme.colorScheme.onErrorContainer
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                "Delete (${deleteTargets.size})",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(group.allPhotos, key = { it.photo.id }) { item ->
                            val isBest = item.photo.id == group.bestPhoto.photo.id
                            val isSelected = item.photo.uri in selectedUris
                            PhotoCard(
                                analyzed = item,
                                isBest = isBest,
                                isSelected = isSelected,
                                onToggle = { onToggle(item.photo.uri) },
                                onPreview = { onPreview(item) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BadPhotosList(
    badPhotos: List<AnalyzedPhoto>,
    selectedUris: Set<Uri>,
    onToggle: (Uri) -> Unit,
    onPreview: (AnalyzedPhoto) -> Unit
) {
    if (badPhotos.isEmpty()) {
        EmptyState("No blurry or poorly exposed photos detected.")
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(badPhotos, key = { it.photo.id }) { item ->
            val isSelected = item.photo.uri in selectedUris
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onPreview(item) },
                border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.error) else null
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = item.photo.uri,
                        contentDescription = item.photo.displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            item.photo.displayName,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            item.reasons.joinToString(" · ") { it.label },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                        Text(
                            String.format(
                                Locale.US,
                                "Quality %d/100 · %.1f MB · Tap to preview",
                                item.qualityScore,
                                item.photo.sizeBytes / (1024.0 * 1024.0)
                            ),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = { onToggle(item.photo.uri) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PhotoCard(
    analyzed: AnalyzedPhoto,
    isBest: Boolean,
    isSelected: Boolean,
    onToggle: () -> Unit,
    onPreview: () -> Unit
) {
    val borderColor = when {
        isSelected -> MaterialTheme.colorScheme.error
        isBest -> Color(0xFF16A34A)
        else -> Color.Transparent
    }
    Card(
        modifier = Modifier
            .width(136.dp)
            .clickable(onClick = onPreview),
        border = if (borderColor != Color.Transparent) BorderStroke(2.dp, borderColor) else null
    ) {
        Column {
            Box {
                AsyncImage(
                    model = analyzed.photo.uri,
                    contentDescription = analyzed.photo.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(136.dp)
                )
                if (isBest) {
                    Row(
                        modifier = Modifier
                            .padding(6.dp)
                            .background(Color(0xCC16A34A), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text("Best", color = Color.White, style = MaterialTheme.typography.labelSmall)
                    }
                }
                Checkbox(
                    checked = isSelected,
                    onCheckedChange = { onToggle() },
                    modifier = Modifier.align(Alignment.TopEnd)
                )
            }
            Column(modifier = Modifier.padding(8.dp)) {
                Text(
                    "Score ${analyzed.qualityScore}/100",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    String.format(Locale.US, "%.1f MB", analyzed.photo.sizeBytes / (1024.0 * 1024.0)),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun EmptyState(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
