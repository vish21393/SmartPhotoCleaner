package com.smartphotocleaner.app

import android.Manifest
import android.app.Activity
import android.content.ComponentCallbacks2
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.Coil
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.memory.MemoryCache
import com.smartphotocleaner.app.intelligence.ResourceMode
import com.smartphotocleaner.app.model.IndexedPhoto
import com.smartphotocleaner.app.model.SimilarGroupView
import com.smartphotocleaner.app.ui.MainUiState
import com.smartphotocleaner.app.ui.MainViewModel
import com.smartphotocleaner.app.ui.theme.SmartPhotoCleanerTheme
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Low-RAM Coil configuration: 10 MB / 10% cap + RGB_565 thumbnails
        val imageLoader = ImageLoader.Builder(applicationContext)
            .memoryCache {
                MemoryCache.Builder(applicationContext)
                    .maxSizePercent(0.10)
                    .build()
            }
            .bitmapConfig(Bitmap.Config.RGB_565)
            .crossfade(false)
            .build()
        Coil.setImageLoader(imageLoader)

        setContent {
            SmartPhotoCleanerTheme {
                SmartPhotoCleanerScreen()
            }
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
            Coil.imageLoader(applicationContext).memoryCache?.clear()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartPhotoCleanerScreen(viewModel: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    var previewContext by remember { mutableStateOf<Pair<IndexedPhoto, SimilarGroupView?>?>(null) }

    val permissionsToRequest = remember {
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            )
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES
            )
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    fun checkAccess(): Pair<Boolean, Boolean> {
        val full = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
        val partial = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            !full && ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            ) == PackageManager.PERMISSION_GRANTED
        } else false
        return (full || partial) to partial
    }

    var accessState by remember { mutableStateOf(checkAccess()) }
    val hasPermission = accessState.first
    val isPartialAccess = accessState.second

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        val updated = checkAccess()
        accessState = updated
        viewModel.setPartialAccess(updated.second)
        if (updated.first) {
            viewModel.scanPage(0)
        }
    }

    val deleteLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        viewModel.onDeleteRequestCompleted(result.resultCode == Activity.RESULT_OK)
    }

    fun triggerDelete(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val intent = viewModel.prepareDelete(uris)
        if (intent != null) {
            deleteLauncher.launch(IntentSenderRequest.Builder(intent.intentSender).build())
        } else {
            viewModel.deleteLegacy(uris)
        }
    }

    LaunchedEffect(hasPermission) {
        viewModel.setPartialAccess(isPartialAccess)
        if (hasPermission && uiState.summary.totalGalleryCount == 0 && !uiState.isScanning) {
            viewModel.scanPage(0)
        }
    }

    Scaffold(
        contentWindowInsets = ScaffoldDefaults.contentWindowInsets,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Smart Photo Cleaner", fontWeight = FontWeight.Bold)
                        Text(
                            "v2.0 · Global SQLite index & low-RAM engine",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    if (hasPermission) {
                        IconButton(onClick = { viewModel.resetKeptAndRescan() }, enabled = !uiState.isScanning) {
                            Icon(Icons.Default.Restore, contentDescription = "Restore kept photos")
                        }
                        IconButton(onClick = { viewModel.scanPage(uiState.currentPage) }, enabled = !uiState.isScanning) {
                            Icon(Icons.Default.Refresh, contentDescription = "Rescan page")
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (uiState.selectedUris.isNotEmpty()) {
                val mb = viewModel.selectedBytes() / (1024.0 * 1024.0)
                Surface(
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                "${uiState.selectedUris.size} selected",
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                String.format(Locale.US, "Free up %.1f MB", mb),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { viewModel.clearSelection() }) {
                                Text("Clear")
                            }
                            Button(
                                onClick = { triggerDelete(uiState.selectedUris.toList()) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (!hasPermission) {
                PermissionCard(onRequestPermission = { permissionLauncher.launch(permissionsToRequest) })
            } else {
                SummaryBanner(
                    uiState = uiState,
                    onSelectSuggested = { viewModel.selectAllSuggested() },
                    onPrevPage = { viewModel.prevPage() },
                    onNextPage = { viewModel.nextPage() }
                )

                if (uiState.isScanning) {
                    val progress = if (uiState.scanPageSize > 0) {
                        uiState.scanProcessedInPage.toFloat() / uiState.scanPageSize.toFloat()
                    } else 0f
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                    )
                    val modeLabel = when (uiState.resourceMode) {
                        ResourceMode.PAUSED_MEMORY -> "Paused (Low Memory) · Waiting for RAM"
                        ResourceMode.PAUSED_THERMAL -> "Paused (Thermal) · Cooling down"
                        ResourceMode.THROTTLED_SINGLE_WORKER -> "1-Worker Gentle Mode"
                        ResourceMode.NORMAL -> "Indexing"
                    }
                    Text(
                        "$modeLabel · ${uiState.scanProcessedInPage} / ${uiState.scanPageSize} on page",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }

                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Similar (${uiState.summary.similarGroups.size})") }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Bad Photos (${uiState.summary.badPhotos.size})") }
                    )
                }

                if (selectedTab == 0) {
                    SimilarGroupsList(
                        groups = uiState.summary.similarGroups,
                        selectedUris = uiState.selectedUris,
                        onToggle = { viewModel.toggleSelection(it) },
                        onPreview = { photo, group ->
                            viewModel.clearExactDupCheck()
                            previewContext = photo to group
                            viewModel.verifyExactDuplicate(photo, group)
                        },
                        onKeepGroup = { viewModel.keepGroupIntact(it) },
                        onDeleteGroup = { uris -> triggerDelete(uris) }
                    )
                } else {
                    BadPhotosList(
                        badPhotos = uiState.summary.badPhotos,
                        selectedUris = uiState.selectedUris,
                        onToggle = { viewModel.toggleSelection(it) },
                        onKeepSingle = { viewModel.keepSingleBadPhoto(it) },
                        onPreview = { photo ->
                            viewModel.clearExactDupCheck()
                            previewContext = photo to null
                        }
                    )
                }
            }
        }
    }

    previewContext?.let { (photo, group) ->
        FullscreenPhotoDialog(
            analyzed = photo,
            exactDupStatus = uiState.exactDupCheckResult,
            isSelected = photo.uri in uiState.selectedUris,
            onToggleSelect = { viewModel.toggleSelection(photo.uri) },
            onKeep = {
                if (group != null) viewModel.keepGroupIntact(group) else viewModel.keepSingleBadPhoto(photo)
                previewContext = null
            },
            onDismiss = { previewContext = null }
        )
    }
}

@Composable
private fun SummaryBanner(
    uiState: MainUiState,
    onSelectSuggested: () -> Unit,
    onPrevPage: () -> Unit,
    onNextPage: () -> Unit
) {
    val totalMb = uiState.summary.totalSuggestedBytes / (1024.0 * 1024.0)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "Page ${uiState.currentPage + 1}/${uiState.totalPages} · ${uiState.summary.totalIndexed} Indexed",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Spacer(Modifier.height(2.dp))
                    Text(
                        String.format(Locale.US, "%.1f MB cleanable across global index", totalMb),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                if (uiState.summary.totalSuggestedBytes > 0L) {
                    FilledTonalButton(onClick = onSelectSuggested) {
                        Text("Auto-Select")
                    }
                }
            }

            if (uiState.totalPages > 1) {
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onPrevPage,
                        enabled = uiState.currentPage > 0,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("Prev 1,000", style = MaterialTheme.typography.labelMedium)
                    }
                    OutlinedButton(
                        onClick = onNextPage,
                        enabled = uiState.currentPage + 1 < uiState.totalPages,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("Next 1,000", style = MaterialTheme.typography.labelMedium)
                        Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun SimilarGroupsList(
    groups: List<SimilarGroupView>,
    selectedUris: Set<Uri>,
    onToggle: (Uri) -> Unit,
    onPreview: (IndexedPhoto, SimilarGroupView) -> Unit,
    onKeepGroup: (SimilarGroupView) -> Unit,
    onDeleteGroup: (List<Uri>) -> Unit
) {
    if (groups.isEmpty()) {
        EmptyState("No similar photo groups found yet.")
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(groups, key = { it.groupId }) { group ->
            val groupSelected = group.allPhotos
                .map { it.uri }
                .filter { it in selectedUris }
            val deleteTargets = groupSelected.ifEmpty {
                group.candidatesToDelete.map { it.uri }
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    val savingsMb = group.potentialSavingsBytes / (1024.0 * 1024.0)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                if (group.hasExactDuplicates) {
                                    "${group.allPhotos.size} Photos · Exact Match"
                                } else {
                                    "${group.allPhotos.size} Similar Photos"
                                },
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                String.format(Locale.US, "Save %.1f MB", savingsMb),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { onKeepGroup(group) },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text("Keep All", style = MaterialTheme.typography.labelMedium)
                            }
                            FilledTonalButton(
                                onClick = { onDeleteGroup(deleteTargets) },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = MaterialTheme.colorScheme.errorContainer,
                                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    "Delete (${deleteTargets.size})",
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(group.allPhotos, key = { it.mediaId }) { item ->
                            val isBest = item.mediaId == group.bestPhoto.mediaId
                            val isSelected = item.uri in selectedUris
                            PhotoCard(
                                analyzed = item,
                                isBest = isBest,
                                isSelected = isSelected,
                                onToggle = { onToggle(item.uri) },
                                onPreview = { onPreview(item, group) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BadPhotosList(
    badPhotos: List<IndexedPhoto>,
    selectedUris: Set<Uri>,
    onToggle: (Uri) -> Unit,
    onKeepSingle: (IndexedPhoto) -> Unit,
    onPreview: (IndexedPhoto) -> Unit
) {
    if (badPhotos.isEmpty()) {
        EmptyState("No blurry or poorly exposed photos detected.")
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(badPhotos, key = { it.mediaId }) { item ->
            val isSelected = item.uri in selectedUris
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onPreview(item) },
                border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.error) else null
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = item.uri,
                        contentDescription = item.displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            item.displayName,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            item.reasons.joinToString(" · ") { it.label },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                        Text(
                            String.format(
                                Locale.US,
                                "Score %d/100 · %.1f MB",
                                item.qualityScore,
                                item.fileSize / (1024.0 * 1024.0)
                            ),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = { onKeepSingle(item) }) {
                        Text("Keep")
                    }
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = { onToggle(item.uri) }
                    )
                }
            }
        }
    }
}

@Composable
private fun FullscreenPhotoDialog(
    analyzed: IndexedPhoto,
    exactDupStatus: String?,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onKeep: () -> Unit,
    onDismiss: () -> Unit
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val transformState = rememberTransformableState { zoomChange, panChange, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 4f)
        if (scale > 1f) {
            offsetX += panChange.x
            offsetY += panChange.y
        } else {
            offsetX = 0f
            offsetY = 0f
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            AsyncImage(
                model = analyzed.uri,
                contentDescription = analyzed.displayName,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offsetX,
                        translationY = offsetY
                    )
                    .transformable(state = transformState)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color(0x99000000))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        analyzed.displayName,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        String.format(
                            Locale.US,
                            "%dx%d · %.1f MB · Score %d/100",
                            analyzed.width,
                            analyzed.height,
                            analyzed.fileSize / (1024.0 * 1024.0),
                            analyzed.qualityScore
                        ),
                        color = Color.LightGray,
                        style = MaterialTheme.typography.labelSmall
                    )
                    if (exactDupStatus != null) {
                        Text(
                            exactDupStatus,
                            color = Color(0xFF93C5FD),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close preview", tint = Color.White)
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(Color(0xB3000000))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    if (analyzed.reasons.isNotEmpty()) {
                        analyzed.reasons.joinToString(" · ") { it.label }
                    } else {
                        "Good quality shot"
                    },
                    color = if (analyzed.reasons.isNotEmpty()) Color(0xFFFCA5A5) else Color(0xFF86EFAC),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onKeep) {
                        Text("Keep", color = Color.White)
                    }
                    Button(
                        onClick = onToggleSelect,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text(if (isSelected) "Selected" else "Delete")
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionCard(onRequestPermission: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    Icons.Default.PhotoLibrary,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(48.dp)
                )
                Text(
                    "Allow Photo Access",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Smart Photo Cleaner v2.0 builds a local SQLite index across 1,000-photo pages to find cross-page duplicates safely on low-RAM phones.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(onClick = onRequestPermission, modifier = Modifier.fillMaxWidth()) {
                    Text("Grant Access & Scan")
                }
            }
        }
    }
}

@Composable
private fun PhotoCard(
    analyzed: IndexedPhoto,
    isBest: Boolean,
    isSelected: Boolean,
    onToggle: () -> Unit,
    onPreview: () -> Unit
) {
    val borderColor = when {
        isSelected -> MaterialTheme.colorScheme.error
        isBest -> Color(0xFF16A34A)
        else -> Color.Transparent
    }
    Card(
        modifier = Modifier
            .width(136.dp)
            .clickable(onClick = onPreview),
        border = if (borderColor != Color.Transparent) BorderStroke(2.dp, borderColor) else null
    ) {
        Column {
            Box {
                AsyncImage(
                    model = analyzed.uri,
                    contentDescription = analyzed.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(136.dp)
                )
                if (isBest) {
                    Row(
                        modifier = Modifier
                            .padding(6.dp)
                            .background(Color(0xCC16A34A), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text("Best", color = Color.White, style = MaterialTheme.typography.labelSmall)
                    }
                }
                Checkbox(
                    checked = isSelected,
                    onCheckedChange = { onToggle() },
                    modifier = Modifier.align(Alignment.TopEnd)
                )
            }
            Column(modifier = Modifier.padding(8.dp)) {
                Text(
                    "Score ${analyzed.qualityScore}/100",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    String.format(Locale.US, "%.1f MB", analyzed.fileSize / (1024.0 * 1024.0)),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun EmptyState(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
