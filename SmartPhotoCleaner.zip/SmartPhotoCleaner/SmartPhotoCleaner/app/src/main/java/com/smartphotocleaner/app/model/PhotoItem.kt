package com.smartphotocleaner.app.model

import android.net.Uri

data class PhotoItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val volumeName: String,
    val sizeBytes: Long,
    val modifiedTimeSeconds: Long,
    val width: Int,
    val height: Int
)

enum class BadPhotoReason(val label: String) {
    BLURRY("Blurry"),
    TOO_DARK("Too Dark"),
    OVEREXPOSED("Overexposed"),
    LOW_RESOLUTION("Low Res"),
    DUPLICATE_OF_BETTER("Similar to Better Shot"),
    EXACT_DUPLICATE("Exact Duplicate")
}

enum class UserDecision {
    AUTO,
    KEEP,
    EXCLUDE,
    DELETED
}

data class IndexedPhoto(
    val mediaId: Long,
    val uri: Uri,
    val displayName: String,
    val volumeName: String,
    val dHash: Long,
    val colorSignature: IntArray, // 4x4 RGB (48 ints)
    val width: Int,
    val height: Int,
    val brightness: Double,
    val sharpness: Double,
    val gradientEntropy: Double,
    val fileSize: Long,
    val modifiedTime: Long,
    val qualityScore: Int,
    val reasons: List<BadPhotoReason>,
    val scanVersion: Int
) {
    val isBad: Boolean get() = reasons.isNotEmpty()
}

data class SimilarGroupView(
    val groupId: Long,
    val anchorPhotoId: Long,
    val bestPhoto: IndexedPhoto,
    val candidatesToDelete: List<IndexedPhoto>,
    val hasExactDuplicates: Boolean
) {
    val allPhotos: List<IndexedPhoto>
        get() = listOf(bestPhoto) + candidatesToDelete

    val potentialSavingsBytes: Long
        get() = candidatesToDelete.sumOf { it.fileSize }
}

data class GlobalSummary(
    val totalIndexed: Int = 0,
    val totalGalleryCount: Int = 0,
    val similarGroups: List<SimilarGroupView> = emptyList(),
    val badPhotos: List<IndexedPhoto> = emptyList(),
    val totalSuggestedBytes: Long = 0L
)
