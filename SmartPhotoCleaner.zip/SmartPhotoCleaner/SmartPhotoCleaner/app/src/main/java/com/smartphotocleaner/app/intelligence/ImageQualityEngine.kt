package com.smartphotocleaner.app.intelligence

import com.smartphotocleaner.app.model.BadPhotoReason
import com.smartphotocleaner.app.model.IndexedPhoto
import kotlin.math.abs
import kotlin.math.min

/**
 * Pure-Kotlin perceptual hashing, 3x3 regional blur, luminance histogram,
 * flat-image protection, and candidate similarity verification.
 * Designed to be 100% JVM unit-testable without Android framework dependencies.
 */
object ImageQualityEngine {

    const val SCAN_VERSION = 2
    const val ANALYSIS_GRID = 96

    // Configurable quality thresholds
    var dHashHammingThreshold = 6
    var maxColorDiffPerChannel = 24.0
    var maxFlatColorDiffPerChannel = 10.0
    var flatGradientThreshold = 8.0
    var maxAspectRatioDiff = 0.15
    var regionalBlurThreshold = 105.0
    var celestialBlurThreshold = 42.0
    var darkMeanThreshold = 42.0
    var overexposedClippedRatio = 0.35
    var minRecommendedPixels = 400 * 400

    data class QualityMetrics(
        val regionalSharpness: Double,
        val globalSharpness: Double,
        val meanBrightness: Double,
        val gradientEntropy: Double,
        val clippedHighlightsRatio: Double,
        val crushedShadowsRatio: Double,
        val isCelestialShot: Boolean
    )

    fun extractBuckets(dHash: Long): IntArray {
        val buckets = IntArray(8)
        for (i in 0 until 8) {
            buckets[i] = ((dHash ushr (i * 8)) and 0xFFL).toInt()
        }
        return buckets
    }

    fun computeDHashFromLuminance(pixels9x8: IntArray): Long {
        var hash = 0L
        var bit = 0
        for (y in 0 until 8) {
            val rowOffset = y * 9
            for (x in 0 until 8) {
                val left = luminance(pixels9x8[rowOffset + x])
                val right = luminance(pixels9x8[rowOffset + x + 1])
                if (left > right) {
                    hash = hash or (1L shl bit)
                }
                bit++
            }
        }
        return hash
    }

    fun computeColorSignatureFrom4x4(pixels4x4: IntArray): IntArray {
        val sig = IntArray(48)
        var idx = 0
        for (p in pixels4x4) {
            sig[idx++] = (p shr 16) and 0xFF
            sig[idx++] = (p shr 8) and 0xFF
            sig[idx++] = p and 0xFF
        }
        return sig
    }

    /**
     * Evaluates 3x3 regional Laplacian variance (top-3 sharpest tiles mean) so
     * portraits with bokeh backgrounds are not penalized as blurry, plus a 16-bin
     * luminance histogram and flat-image gradient entropy.
     */
    fun evaluateQualityFromGrid(
        pixels: IntArray,
        grayBuffer: DoubleArray,
        size: Int = ANALYSIS_GRID
    ): QualityMetrics {
        val totalPixels = size * size
        var sumBrightness = 0.0
        var darkCount = 0
        var brightCount = 0
        var clippedCount = 0
        var maxLum = 0.0

        for (i in 0 until totalPixels) {
            val lum = luminance(pixels[i])
            grayBuffer[i] = lum
            sumBrightness += lum
            if (lum <= 40.0) darkCount++
            if (lum >= 195.0) brightCount++
            if (lum >= 245.0) clippedCount++
            if (lum > maxLum) maxLum = lum
        }

        val meanBrightness = sumBrightness / totalPixels
        val crushedShadowsRatio = darkCount.toDouble() / totalPixels
        val clippedHighlightsRatio = clippedCount.toDouble() / totalPixels
        val brightRatio = brightCount.toDouble() / totalPixels

        val isCelestial = crushedShadowsRatio >= 0.45 &&
            brightRatio in 0.0015..0.22 &&
            maxLum >= 210.0 &&
            (maxLum - meanBrightness) >= 140.0

        // Gradient entropy (average neighbor difference) to detect flat/solid screenshots
        var gradSum = 0.0
        var gradSamples = 0
        for (y in 0 until size - 1) {
            val row = y * size
            for (x in 0 until size - 1) {
                val c = grayBuffer[row + x]
                gradSum += abs(c - grayBuffer[row + x + 1]) + abs(c - grayBuffer[row + size + x])
                gradSamples += 2
            }
        }
        val gradientEntropy = if (gradSamples > 0) gradSum / gradSamples else 0.0

        // 3x3 regional Laplacian variance
        val tileSize = size / 3
        val tileVariances = DoubleArray(9)
        var globalLapSum = 0.0
        var globalLapSqSum = 0.0
        var globalCount = 0

        for (ty in 0 until 3) {
            for (tx in 0 until 3) {
                val yStart = (ty * tileSize).coerceAtLeast(1)
                val yEnd = ((ty + 1) * tileSize).coerceAtMost(size - 1)
                val xStart = (tx * tileSize).coerceAtLeast(1)
                val xEnd = ((tx + 1) * tileSize).coerceAtMost(size - 1)

                var tSum = 0.0
                var tSqSum = 0.0
                var tCount = 0

                for (y in yStart until yEnd) {
                    val row = y * size
                    for (x in xStart until xEnd) {
                        val center = grayBuffer[row + x]
                        val lap = grayBuffer[row - size + x] +
                            grayBuffer[row + size + x] +
                            grayBuffer[row + x - 1] +
                            grayBuffer[row + x + 1] -
                            4.0 * center
                        tSum += lap
                        tSqSum += lap * lap
                        tCount++

                        globalLapSum += lap
                        globalLapSqSum += lap * lap
                        globalCount++
                    }
                }
                tileVariances[ty * 3 + tx] = if (tCount > 0) {
                    val mean = tSum / tCount
                    (tSqSum / tCount) - (mean * mean)
                } else 0.0
            }
        }

        tileVariances.sortDescending()
        val top3RegionalSharpness = (tileVariances[0] + tileVariances[1] + tileVariances[2]) / 3.0
        val globalSharpness = if (globalCount > 0) {
            val gMean = globalLapSum / globalCount
            (globalLapSqSum / globalCount) - (gMean * gMean)
        } else 0.0

        return QualityMetrics(
            regionalSharpness = top3RegionalSharpness,
            globalSharpness = globalSharpness,
            meanBrightness = meanBrightness,
            gradientEntropy = gradientEntropy,
            clippedHighlightsRatio = clippedHighlightsRatio,
            crushedShadowsRatio = crushedShadowsRatio,
            isCelestialShot = isCelestial
        )
    }

    fun classifyReasons(metrics: QualityMetrics, width: Int, height: Int): List<BadPhotoReason> {
        val reasons = mutableListOf<BadPhotoReason>()
        val blurThreshold = if (metrics.isCelestialShot) celestialBlurThreshold else regionalBlurThreshold
        val effectiveSharpness = if (metrics.isCelestialShot) metrics.regionalSharpness else metrics.regionalSharpness

        if (effectiveSharpness < blurThreshold && metrics.gradientEntropy >= flatGradientThreshold) {
            reasons.add(BadPhotoReason.BLURRY)
        }
        if (!metrics.isCelestialShot &&
            metrics.meanBrightness < darkMeanThreshold &&
            metrics.crushedShadowsRatio > 0.72
        ) {
            reasons.add(BadPhotoReason.TOO_DARK)
        } else if (metrics.clippedHighlightsRatio > overexposedClippedRatio && metrics.meanBrightness > 205.0) {
            reasons.add(BadPhotoReason.OVEREXPOSED)
        }
        if (width > 0 && height > 0 && (width * height) < minRecommendedPixels) {
            reasons.add(BadPhotoReason.LOW_RESOLUTION)
        }
        return reasons
    }

    fun calculateQualityScore(metrics: QualityMetrics, width: Int, height: Int): Int {
        val sharpnessPoints = min(55.0, (metrics.regionalSharpness / 450.0) * 55.0)
        val effectiveBrightness = if (metrics.isCelestialShot) 128.0 else metrics.meanBrightness
        val brightnessPenalty = abs(effectiveBrightness - 128.0) / 128.0
        val brightnessPoints = (1.0 - brightnessPenalty).coerceIn(0.0, 1.0) * 30.0
        val mp = (width.toDouble() * height.toDouble()) / 1_000_000.0
        val resPoints = if (mp <= 0.0) 7.5 else min(15.0, (mp / 12.0) * 15.0)
        return (sharpnessPoints + brightnessPoints + resPoints).toInt().coerceIn(0, 100)
    }

    fun areVisuallySimilar(a: IndexedPhoto, b: IndexedPhoto): Boolean {
        if (a.width > 0 && a.height > 0 && b.width > 0 && b.height > 0) {
            val ratioA = a.width.toDouble() / a.height.toDouble()
            val ratioB = b.width.toDouble() / b.height.toDouble()
            if (abs(ratioA - ratioB) > maxAspectRatioDiff) return false
        }

        val hamming = java.lang.Long.bitCount(a.dHash xor b.dHash)
        if (hamming > dHashHammingThreshold) return false

        var totalDiff = 0.0
        for (i in a.colorSignature.indices) {
            totalDiff += abs(a.colorSignature[i] - b.colorSignature[i])
        }
        val meanChannelDiff = totalDiff / a.colorSignature.size

        // Flat-image protection: uniform/solid screenshots must match color very tightly
        val isFlat = a.gradientEntropy < flatGradientThreshold || b.gradientEntropy < flatGradientThreshold
        val colorLimit = if (isFlat) maxFlatColorDiffPerChannel else maxColorDiffPerChannel
        return meanChannelDiff <= colorLimit
    }

    private inline fun luminance(pixel: Int): Double {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF
        return 0.299 * r + 0.587 * g + 0.114 * b
    }
}
