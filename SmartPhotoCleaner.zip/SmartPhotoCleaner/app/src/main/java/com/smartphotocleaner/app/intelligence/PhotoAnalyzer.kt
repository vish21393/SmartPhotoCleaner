package com.smartphotocleaner.app.intelligence

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.util.Size
import com.smartphotocleaner.app.model.AnalyzedPhoto
import com.smartphotocleaner.app.model.BadPhotoReason
import com.smartphotocleaner.app.model.PhotoItem
import com.smartphotocleaner.app.model.ScanSummary
import com.smartphotocleaner.app.model.SimilarPhotoGroup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.min

/**
 * On-device photo intelligence engine:
 * 1. Computes 64-bit Difference Hash (dHash) to cluster visually similar or burst photos.
 * 2. Computes Laplacian variance on grayscale thumbnails to detect blurry shots.
 * 3. Evaluates mean luminance & clipping to detect underexposed/overexposed photos.
 * 4. Scores each photo (0-100) and picks the best keeper in every similar group.
 */
class PhotoAnalyzer(private val context: Context) {

    companion object {
        private const val DHASH_HAMMING_THRESHOLD = 8
        private const val BLUR_VARIANCE_THRESHOLD = 110.0
        private const val DARK_BRIGHTNESS_THRESHOLD = 42.0
        private const val OVEREXPOSED_BRIGHTNESS_THRESHOLD = 218.0
        private const val MIN_RECOMMENDED_PIXELS = 400 * 400
    }

    suspend fun analyzeGallery(
        photos: List<PhotoItem>,
        onProgress: (processed: Int, total: Int) -> Unit
    ): ScanSummary = withContext(Dispatchers.Default) {
        val analyzed = mutableListOf<AnalyzedPhoto>()
        val total = photos.size

        photos.forEachIndexed { index, item ->
            val result = analyzeSinglePhoto(item)
            if (result != null) {
                analyzed.add(result)
            }
            if (index % 5 == 0 || index == total - 1) {
                onProgress(index + 1, total)
            }
        }

        val similarGroups = clusterSimilarPhotos(analyzed)
        val duplicateIds = similarGroups
            .flatMap { it.candidatesToDelete }
            .map { it.photo.id }
            .toSet()

        val badPhotos = analyzed
            .filter { it.isBad && it.photo.id !in duplicateIds }
            .sortedBy { it.qualityScore }

        val suggestedIds = duplicateIds + badPhotos.map { it.photo.id }.toSet()
        val totalBytes = analyzed
            .filter { it.photo.id in suggestedIds }
            .sumOf { it.photo.sizeBytes }

        ScanSummary(
            totalScanned = analyzed.size,
            similarGroups = similarGroups,
            badPhotos = badPhotos,
            totalSuggestedBytes = totalBytes
        )
    }

    private fun analyzeSinglePhoto(item: PhotoItem): AnalyzedPhoto? {
        val bitmap = loadAnalysisThumbnail(item) ?: return null
        return try {
            val dHash = computeDHash(bitmap)
            val (sharpness, brightness) = computeSharpnessAndBrightness(bitmap)

            val reasons = mutableListOf<BadPhotoReason>()
            if (sharpness < BLUR_VARIANCE_THRESHOLD) {
                reasons.add(BadPhotoReason.BLURRY)
            }
            if (brightness < DARK_BRIGHTNESS_THRESHOLD) {
                reasons.add(BadPhotoReason.TOO_DARK)
            } else if (brightness > OVEREXPOSED_BRIGHTNESS_THRESHOLD) {
                reasons.add(BadPhotoReason.OVEREXPOSED)
            }
            if (item.width > 0 && item.height > 0 && (item.width * item.height) < MIN_RECOMMENDED_PIXELS) {
                reasons.add(BadPhotoReason.LOW_RESOLUTION)
            }

            val qualityScore = calculateQualityScore(
                sharpness = sharpness,
                brightness = brightness,
                width = item.width,
                height = item.height
            )

            AnalyzedPhoto(
                photo = item,
                dHash = dHash,
                sharpnessScore = sharpness,
                brightnessMean = brightness,
                qualityScore = qualityScore,
                reasons = reasons
            )
        } finally {
            bitmap.recycle()
        }
    }

    private fun loadAnalysisThumbnail(item: PhotoItem): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                context.contentResolver.loadThumbnail(item.uri, Size(160, 160), null)
            } else {
                val options = BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                context.contentResolver.openInputStream(item.uri)?.use {
                    BitmapFactory.decodeStream(it, null, options)
                }
                val maxDim = maxOf(options.outWidth, options.outHeight)
                val sampleSize = if (maxDim > 160) maxDim / 160 else 1
                val decodeOpts = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize.coerceAtLeast(1)
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                context.contentResolver.openInputStream(item.uri)?.use {
                    BitmapFactory.decodeStream(it, null, decodeOpts)
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * 64-bit Difference Hash (dHash):
     * Scales image to 9x8 grayscale and compares each pixel to its right neighbor.
     */
    private fun computeDHash(source: Bitmap): Long {
        val scaled = Bitmap.createScaledBitmap(source, 9, 8, true)
        var hash = 0L
        var bit = 0
        try {
            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    val left = luminance(scaled.getPixel(x, y))
                    val right = luminance(scaled.getPixel(x + 1, y))
                    if (left > right) {
                        hash = hash or (1L shl bit)
                    }
                    bit++
                }
            }
        } finally {
            if (scaled !== source) scaled.recycle()
        }
        return hash
    }

    /**
     * Computes Laplacian variance (sharpness) and mean luminance (0-255) on a 128x128 grid.
     */
    private fun computeSharpnessAndBrightness(source: Bitmap): Pair<Double, Double> {
        val size = 128
        val scaled = Bitmap.createScaledBitmap(source, size, size, true)
        val gray = DoubleArray(size * size)
        var sumBrightness = 0.0

        try {
            for (y in 0 until size) {
                for (x in 0 until size) {
                    val lum = luminance(scaled.getPixel(x, y))
                    gray[y * size + x] = lum
                    sumBrightness += lum
                }
            }
        } finally {
            if (scaled !== source) scaled.recycle()
        }

        val meanBrightness = sumBrightness / (size * size)

        // 3x3 Laplacian operator: [0, 1, 0; 1, -4, 1; 0, 1, 0]
        val lapValues = DoubleArray((size - 2) * (size - 2))
        var lapSum = 0.0
        var idx = 0
        for (y in 1 until size - 1) {
            for (x in 1 until size - 1) {
                val center = gray[y * size + x]
                val lap = gray[(y - 1) * size + x] +
                    gray[(y + 1) * size + x] +
                    gray[y * size + (x - 1)] +
                    gray[y * size + (x + 1)] -
                    4.0 * center
                lapValues[idx++] = lap
                lapSum += lap
            }
        }

        val lapMean = lapSum / lapValues.size
        var varianceSum = 0.0
        for (v in lapValues) {
            val diff = v - lapMean
            varianceSum += diff * diff
        }
        val variance = varianceSum / lapValues.size
        return variance to meanBrightness
    }

    private fun luminance(pixel: Int): Double {
        val r = Color.red(pixel)
        val g = Color.green(pixel)
        val b = Color.blue(pixel)
        return 0.299 * r + 0.587 * g + 0.114 * b
    }

    private fun calculateQualityScore(
        sharpness: Double,
        brightness: Double,
        width: Int,
        height: Int
    ): Int {
        // Sharpness contributes up to 55 points
        val sharpnessPoints = min(55.0, (sharpness / 450.0) * 55.0)
        // Ideal brightness centered around 128 -> up to 30 points
        val brightnessPenalty = abs(brightness - 128.0) / 128.0
        val brightnessPoints = (1.0 - brightnessPenalty).coerceIn(0.0, 1.0) * 30.0
        // Resolution contributes up to 15 points (12MP+ = full points)
        val mp = (width.toDouble() * height.toDouble()) / 1_000_000.0
        val resPoints = if (mp <= 0.0) 7.5 else min(15.0, (mp / 12.0) * 15.0)

        return (sharpnessPoints + brightnessPoints + resPoints).toInt().coerceIn(0, 100)
    }

    private fun clusterSimilarPhotos(analyzed: List<AnalyzedPhoto>): List<SimilarPhotoGroup> {
        val visited = BooleanArray(analyzed.size)
        val groups = mutableListOf<SimilarPhotoGroup>()

        for (i in analyzed.indices) {
            if (visited[i]) continue
            val seed = analyzed[i]
            val cluster = mutableListOf(seed)
            visited[i] = true

            for (j in i + 1 until analyzed.size) {
                if (visited[j]) continue
                val candidate = analyzed[j]
                val hamming = java.lang.Long.bitCount(seed.dHash xor candidate.dHash)
                if (hamming <= DHASH_HAMMING_THRESHOLD) {
                    cluster.add(candidate)
                    visited[j] = true
                }
            }

            if (cluster.size >= 2) {
                val sorted = cluster.sortedByDescending { it.qualityScore }
                val best = sorted.first()
                val others = sorted.drop(1).map {
                    if (BadPhotoReason.DUPLICATE_OF_BETTER in it.reasons) it
                    else it.copy(reasons = it.reasons + BadPhotoReason.DUPLICATE_OF_BETTER)
                }
                groups.add(
                    SimilarPhotoGroup(
                        groupId = "group_${best.photo.id}",
                        bestPhoto = best,
                        candidatesToDelete = others
                    )
                )
            }
        }
        return groups
    }
}
