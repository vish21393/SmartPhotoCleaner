package com.smartphotocleaner.app.model

import android.net.Uri

data class PhotoItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val sizeBytes: Long,
    val dateTakenMillis: Long,
    val width: Int,
    val height: Int
)

enum class BadPhotoReason(val label: String) {
    BLURRY("Blurry"),
    TOO_DARK("Too Dark"),
    OVEREXPOSED("Overexposed"),
    LOW_RESOLUTION("Low Res"),
    DUPLICATE_OF_BETTER("Similar to Better Shot")
}

data class AnalyzedPhoto(
    val photo: PhotoItem,
    val dHash: Long,
    val sharpnessScore: Double,
    val brightnessMean: Double,
    val qualityScore: Int, // 0..100
    val reasons: List<BadPhotoReason>
) {
    val isBad: Boolean get() = reasons.isNotEmpty()
}

data class SimilarPhotoGroup(
    val groupId: String,
    val bestPhoto: AnalyzedPhoto,
    val candidatesToDelete: List<AnalyzedPhoto>
) {
    val allPhotos: List<AnalyzedPhoto>
        get() = listOf(bestPhoto) + candidatesToDelete

    val potentialSavingsBytes: Long
        get() = candidatesToDelete.sumOf { it.photo.sizeBytes }
}

data class ScanSummary(
    val totalScanned: Int = 0,
    val similarGroups: List<SimilarPhotoGroup> = emptyList(),
    val badPhotos: List<AnalyzedPhoto> = emptyList(),
    val totalSuggestedBytes: Long = 0L
)
