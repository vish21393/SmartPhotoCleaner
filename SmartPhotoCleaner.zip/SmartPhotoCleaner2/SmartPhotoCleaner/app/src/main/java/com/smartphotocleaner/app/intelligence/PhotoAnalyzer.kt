package com.smartphotocleaner.app.intelligence

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.util.Size
import com.smartphotocleaner.app.model.AnalyzedPhoto
import com.smartphotocleaner.app.model.BadPhotoReason
import com.smartphotocleaner.app.model.PhotoItem
import com.smartphotocleaner.app.model.ScanSummary
import com.smartphotocleaner.app.model.SimilarPhotoGroup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.min

/**
 * On-device photo intelligence engine:
 * 1. Uses 64-bit dHash + 4x4 RGB color signature + aspect ratio + brightness check
 *    so visually unrelated photos (like bright vs dark images) are never clubbed together.
 * 2. Computes Laplacian variance on grayscale thumbnails to detect blurry shots.
 * 3. Evaluates mean luminance to detect underexposed/overexposed photos.
 */
class PhotoAnalyzer(private val context: Context) {

    companion object {
        private const val DHASH_HAMMING_THRESHOLD = 5
        private const val MAX_COLOR_DIFF_PER_CHANNEL = 24.0
        private const val MAX_BRIGHTNESS_DIFF = 35.0
        private const val MAX_ASPECT_RATIO_DIFF = 0.15
        private const val BLUR_VARIANCE_THRESHOLD = 110.0
        private const val DARK_BRIGHTNESS_THRESHOLD = 42.0
        private const val OVEREXPOSED_BRIGHTNESS_THRESHOLD = 218.0
        private const val MIN_RECOMMENDED_PIXELS = 400 * 400
    }

    suspend fun analyzeGallery(
        photos: List<PhotoItem>,
        onProgress: (processed: Int, total: Int) -> Unit
    ): ScanSummary = withContext(Dispatchers.Default) {
        val analyzed = mutableListOf<AnalyzedPhoto>()
        val total = photos.size

        photos.forEachIndexed { index, item ->
            val result = analyzeSinglePhoto(item)
            if (result != null) {
                analyzed.add(result)
            }
            if (index % 5 == 0 || index == total - 1) {
                onProgress(index + 1, total)
            }
        }

        val similarGroups = clusterSimilarPhotos(analyzed)
        val duplicateIds = similarGroups
            .flatMap { it.candidatesToDelete }
            .map { it.photo.id }
            .toSet()

        val badPhotos = analyzed
            .filter { it.isBad && it.photo.id !in duplicateIds }
            .sortedBy { it.qualityScore }

        val suggestedIds = duplicateIds + badPhotos.map { it.photo.id }.toSet()
        val totalBytes = analyzed
            .filter { it.photo.id in suggestedIds }
            .sumOf { it.photo.sizeBytes }

        ScanSummary(
            totalScanned = analyzed.size,
            similarGroups = similarGroups,
            badPhotos = badPhotos,
            totalSuggestedBytes = totalBytes
        )
    }

    private fun analyzeSinglePhoto(item: PhotoItem): AnalyzedPhoto? {
        val bitmap = loadAnalysisThumbnail(item) ?: return null
        return try {
            val dHash = computeDHash(bitmap)
            val colorSig = computeColorSignature(bitmap)
            val metrics = computeImageMetrics(bitmap)
            val isCelestial = metrics.isCelestialShot

            val effectiveSharpness = if (isCelestial) metrics.subjectSharpness else metrics.globalSharpness
            val blurThreshold = if (isCelestial) 45.0 else BLUR_VARIANCE_THRESHOLD

            val reasons = mutableListOf<BadPhotoReason>()
            if (effectiveSharpness < blurThreshold) {
                reasons.add(BadPhotoReason.BLURRY)
            }
            if (!isCelestial && metrics.meanBrightness < DARK_BRIGHTNESS_THRESHOLD) {
                reasons.add(BadPhotoReason.TOO_DARK)
            } else if (metrics.meanBrightness > OVEREXPOSED_BRIGHTNESS_THRESHOLD) {
                reasons.add(BadPhotoReason.OVEREXPOSED)
            }
            if (item.width > 0 && item.height > 0 && (item.width * item.height) < MIN_RECOMMENDED_PIXELS) {
                reasons.add(BadPhotoReason.LOW_RESOLUTION)
            }

            val qualityScore = calculateQualityScore(
                sharpness = effectiveSharpness,
                brightness = if (isCelestial) 128.0 else metrics.meanBrightness,
                width = item.width,
                height = item.height
            )

            AnalyzedPhoto(
                photo = item,
                dHash = dHash,
                colorSignature = colorSig,
                sharpnessScore = sharpness,
                brightnessMean = brightness,
                qualityScore = qualityScore,
                reasons = reasons
            )
        } finally {
            bitmap.recycle()
        }
    }

    private fun loadAnalysisThumbnail(item: PhotoItem): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                context.contentResolver.loadThumbnail(item.uri, Size(160, 160), null)
            } else {
                val options = BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                context.contentResolver.openInputStream(item.uri)?.use {
                    BitmapFactory.decodeStream(it, null, options)
                }
                val maxDim = maxOf(options.outWidth, options.outHeight)
                val sampleSize = if (maxDim > 160) maxDim / 160 else 1
                val decodeOpts = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize.coerceAtLeast(1)
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                context.contentResolver.openInputStream(item.uri)?.use {
                    BitmapFactory.decodeStream(it, null, decodeOpts)
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun computeDHash(source: Bitmap): Long {
        val scaled = Bitmap.createScaledBitmap(source, 9, 8, true)
        var hash = 0L
        var bit = 0
        try {
            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    val left = luminance(scaled.getPixel(x, y))
                    val right = luminance(scaled.getPixel(x + 1, y))
                    if (left > right) {
                        hash = hash or (1L shl bit)
                    }
                    bit++
                }
            }
        } finally {
            if (scaled !== source) scaled.recycle()
        }
        return hash
    }

    private fun computeColorSignature(source: Bitmap): IntArray {
        val scaled = Bitmap.createScaledBitmap(source, 4, 4, true)
        val sig = IntArray(48)
        var idx = 0
        try {
            for (y in 0 until 4) {
                for (x in 0 until 4) {
                    val p = scaled.getPixel(x, y)
                    sig[idx++] = Color.red(p)
                    sig[idx++] = Color.green(p)
                    sig[idx++] = Color.blue(p)
                }
            }
        } finally {
            if (scaled !== source) scaled.recycle()
        }
        return sig
    }

    private data class ImageMetrics(
        val globalSharpness: Double,
        val subjectSharpness: Double,
        val meanBrightness: Double,
        val isCelestialShot: Boolean
    )

    private fun computeImageMetrics(source: Bitmap): ImageMetrics {
        val size = 128
        val totalPixels = size * size
        val scaled = Bitmap.createScaledBitmap(source, size, size, true)
        val gray = DoubleArray(totalPixels)
        var sumBrightness = 0.0
        var darkCount = 0
        var brightCount = 0
        var maxLum = 0.0

        try {
            for (y in 0 until size) {
                for (x in 0 until size) {
                    val lum = luminance(scaled.getPixel(x, y))
                    gray[y * size + x] = lum
                    sumBrightness += lum
                    if (lum <= 45.0) darkCount++
                    if (lum >= 195.0) brightCount++
                    if (lum > maxLum) maxLum = lum
                }
            }
        } finally {
            if (scaled !== source) scaled.recycle()
        }

        val meanBrightness = sumBrightness / totalPixels
        val darkRatio = darkCount.toDouble() / totalPixels
        val brightRatio = brightCount.toDouble() / totalPixels
        val isCelestial = darkRatio >= 0.45 &&
            brightRatio in 0.0015..0.22 &&
            maxLum >= 210.0 &&
            (maxLum - meanBrightness) >= 140.0

        val lapValues = DoubleArray((size - 2) * (size - 2))
        val subjectLapValues = ArrayList<Double>(1024)
        var lapSum = 0.0
        var subjectLapSum = 0.0
        var idx = 0

        for (y in 1 until size - 1) {
            for (x in 1 until size - 1) {
                val center = gray[y * size + x]
                val lap = gray[(y - 1) * size + x] +
                    gray[(y + 1) * size + x] +
                    gray[y * size + (x - 1)] +
                    gray[y * size + (x + 1)] -
                    4.0 * center
                lapValues[idx++] = lap
                lapSum += lap
                if (center >= 75.0) {
                    subjectLapValues.add(lap)
                    subjectLapSum += lap
                }
            }
        }

        val lapMean = lapSum / lapValues.size
        var varianceSum = 0.0
        for (v in lapValues) {
            val diff = v - lapMean
            varianceSum += diff * diff
        }
        val globalVariance = varianceSum / lapValues.size

        val subjectVariance = if (subjectLapValues.size >= 16) {
            val sMean = subjectLapSum / subjectLapValues.size
            var sVar = 0.0
            for (v in subjectLapValues) {
                val diff = v - sMean
                sVar += diff * diff
            }
            sVar / subjectLapValues.size
        } else {
            globalVariance
        }

        return ImageMetrics(
            globalSharpness = globalVariance,
            subjectSharpness = subjectVariance,
            meanBrightness = meanBrightness,
            isCelestialShot = isCelestial
        )
    }

    private fun luminance(pixel: Int): Double {
        val r = Color.red(pixel)
        val g = Color.green(pixel)
        val b = Color.blue(pixel)
        return 0.299 * r + 0.587 * g + 0.114 * b
    }

    private fun calculateQualityScore(
        sharpness: Double,
        brightness: Double,
        width: Int,
        height: Int
    ): Int {
        val sharpnessPoints = min(55.0, (sharpness / 450.0) * 55.0)
        val brightnessPenalty = abs(brightness - 128.0) / 128.0
        val brightnessPoints = (1.0 - brightnessPenalty).coerceIn(0.0, 1.0) * 30.0
        val mp = (width.toDouble() * height.toDouble()) / 1_000_000.0
        val resPoints = if (mp <= 0.0) 7.5 else min(15.0, (mp / 12.0) * 15.0)

        return (sharpnessPoints + brightnessPoints + resPoints).toInt().coerceIn(0, 100)
    }

    private fun areVisuallySimilar(a: AnalyzedPhoto, b: AnalyzedPhoto): Boolean {
        // 1. Aspect ratio check
        if (a.photo.width > 0 && a.photo.height > 0 && b.photo.width > 0 && b.photo.height > 0) {
            val ratioA = a.photo.width.toDouble() / a.photo.height.toDouble()
            val ratioB = b.photo.width.toDouble() / b.photo.height.toDouble()
            if (abs(ratioA - ratioB) > MAX_ASPECT_RATIO_DIFF) return false
        }

        // 2. Overall brightness check
        if (abs(a.brightnessMean - b.brightnessMean) > MAX_BRIGHTNESS_DIFF) return false

        // 3. Structural dHash check
        val hamming = java.lang.Long.bitCount(a.dHash xor b.dHash)
        if (hamming > DHASH_HAMMING_THRESHOLD) return false

        // 4. 4x4 RGB color grid similarity
        var totalDiff = 0.0
        for (i in a.colorSignature.indices) {
            totalDiff += abs(a.colorSignature[i] - b.colorSignature[i])
        }
        val meanChannelDiff = totalDiff / a.colorSignature.size
        return meanChannelDiff <= MAX_COLOR_DIFF_PER_CHANNEL
    }

    private fun clusterSimilarPhotos(analyzed: List<AnalyzedPhoto>): List<SimilarPhotoGroup> {
        val visited = BooleanArray(analyzed.size)
        val groups = mutableListOf<SimilarPhotoGroup>()

        for (i in analyzed.indices) {
            if (visited[i]) continue
            val seed = analyzed[i]
            val cluster = mutableListOf(seed)
            visited[i] = true

            for (j in i + 1 until analyzed.size) {
                if (visited[j]) continue
                val candidate = analyzed[j]
                if (areVisuallySimilar(seed, candidate)) {
                    cluster.add(candidate)
                    visited[j] = true
                }
            }

            if (cluster.size >= 2) {
                val sorted = cluster.sortedByDescending { it.qualityScore }
                val best = sorted.first()
                val others = sorted.drop(1).map {
                    if (BadPhotoReason.DUPLICATE_OF_BETTER in it.reasons) it
                    else it.copy(reasons = it.reasons + BadPhotoReason.DUPLICATE_OF_BETTER)
                }
                groups.add(
                    SimilarPhotoGroup(
                        groupId = "group_${best.photo.id}",
                        bestPhoto = best,
                        candidatesToDelete = others
                    )
                )
            }
        }
        return groups
    }
}
